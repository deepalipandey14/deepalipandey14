// These scripts are made available when the app is served or deployed on Firebase Hosting
// If you do not serve/host your project using Firebase Hosting see https://firebase.google.com/docs/web/setup
importScripts('https://www.gstatic.com/firebasejs/7.14.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/7.14.0/firebase-messaging.js');
importScripts('https://www.gstatic.com/firebasejs/7.14.0/init.js');
if ('navigator.serviceWorker' in navigator)
{
navigator.serviceWorker.register('/firebase-messaging-sw.js').then((resp)=>
{
console.warn("resp",resp)
}).catch((e)=>{
console.error(e)
}
)
}

else{
  console.log("your sw is not working...")
}

        // Initialize Firebase
        firebase.initializeApp(
            {
                messagingSenderId: "667878708983",
            }
        );
        //firebase.analytics();


const initMessaging =firebase.messaging();
messaging.setBackgroundMessageHandler(function(payload) {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  // Customize notification here
  const notificationTitle = 'Background Message Title';
  const notificationOptions = {
    body: 'Background Message body.',
    icon: './firebase-logo.png'
  };

  return self.registration.showNotification(notificationTitle,
    notificationOptions);
});
// [END background_handler]
