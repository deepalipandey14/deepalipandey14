import React,{useEffect,useState} from 'react';
import {Container, Row, Col} from 'reactstrap';
import { useMediaQuery } from 'react-responsive';
import CatTop from '../Categori/CatTop';
import Header from '../Header'
import Footer from '../footer/Footer'
import CatContainer1 from '../Categori/CatContainer1';
import CatSubContainer2 from '../Categori/CatSubContainer2';
import Heading from '../Home/Heading';
import Last from '../Home/Last';
import Bg from '../page/BgCompo'
import ColordIcon from '../Categori/ColordIcon';
import CardList1 from '../Categori/CardList1';
import Page from '../Page';
import Ad from '../Ad';
import ad3 from '../../images/ad3.jpg';
import axios from 'axios';
const SubCat=(props)=>
{
   const [news, setNews]=useState();
   const [reNews, setReNews]=useState();
 console.log(props)
      useEffect(() => {
      async function getData()
     
      {let a
          const res = await axios.get(`https://jjn.ascentrek.co.in/api/News/GetBySubCategory?url=almora`)
          const cat1 = res.data.NewsList.map((c,i)=>
          {
           if(i===0)
           {
           a= <Bg href={c.Url}title={c.Title} img={c.CoverImage} fName={c.CreatedByFirstName}mName= {c.CreatedByMiddleName} lName={c.CreatedByLastName} date={c.CreatedOn}/>
           } 
           else if(i>=1 && i<=2)
           {
            a=<Last src={c.CoverImage} heading={c.Title} href={c.Url}/>
            
           }
           else{
             a=null
           }
           return a
          });
          setReNews(cat1)
         const cat = res.data.NewsList.map((cvalue,i)=>
         { 
        a=i>=4 && i<=10?<Col xs="6" sm="4">
           
         <CardList1 key={i} title={cvalue.ShortDescription} img={cvalue.CoverImage} date={cvalue.CreatedOn} fName={cvalue.CreatedByFirstName}mName={cvalue.CreatedByMiddleName}lName={cvalue.CreatedByLastName}/>
           </Col>:null
            return a;
         })
         setNews(cat);
      } 
      getData();  
    
    },[]);
  
    const dis = useMediaQuery({ query: '(max-width: 1300px)' })
    const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
    return (
        <div>
        <Header/>
            {isTabletOrMobile && <Container fluid={true} style={{paddingRight:"90px",paddingLeft:"90px"}}>
                  <CatTop CatName={props.catName} subcat=""/>
                   {/*<CatContainer1 name={props.catName} />*/}
                   <Row>
                     <Col sm="8">    
                     <Row>
                         {news}
                     </Row>
                     <Row className=""><Page/></Row>
                     </Col>
                        <Col sm="4">
                        <Heading value1="Stay Connected"/>
                        <ColordIcon/>
                       <Heading value1="Recent News"/>
                       

                      {reNews}

                       <Ad ad={ad3}/>
                       </Col>
                       
                    </Row>
                 
                  
                
            </Container>
            }
           {dis &&  <Container fluid={true} >
           <CatTop CatName={props.catName}/>
                   {/*<CatContainer1 name={props.name} />*/}
           <Row>
     
    
                     <Col sm="8">    
                     <Row>
                         {news}
                     </Row>
                     <Row ><Page/></Row>
                     </Col>
                        <Col sm="4">
                        <Heading value1="Stay Connected"/>
                        <ColordIcon/>

                    
                       <Heading value1="Recent News"/>
                      {reNews}
                      <Ad ad={ad3}/>
                       </Col>
                  

                    </Row>

       </Container>}
       
     <Footer/>
        </div>
    )
}
export default SubCat;