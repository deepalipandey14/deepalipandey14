import React,{useEffect,useState} from 'react';
import {Container, Row, Col} from 'reactstrap';
import { useMediaQuery } from 'react-responsive';
import CatTop from '../Categori/CatTop';
import CatContainer1 from '../Categori/CatContainer1';
import Heading from '../Home/Heading';
import Last from '../Home/Last';
import Bg from '../page/BgCompo'
import ColordIcon from '../Categori/ColordIcon';
//import CardList1 from '../Categori/CardList1';
//import Page from '../Page';
import Ad from '../Ad';

import axios from 'axios';
import CatContainer2 from '../Categori/CatConatainer2';
const Cat=(props)=>
{    
 
   const [reNews, setReNews]=useState();
   const [ad2, setAd2]= useState();
    const [ad3, setAd3]= useState(); 
    const [adBottom, setAdBottom]= useState();
try{
      useEffect(() => {
        let s;
      async function getData()
      {let a
        const r = await axios.get(`https://panel.jagratjantanews.com/api/News/AllNews`)
        const add1 = await axios.get(`https://panel.jagratjantanews.com/api/AdvertiseCategory/MiddleTop`)
        setAd2( add1.data.AdvertisePath)
        const add2 = await axios.get(`https://panel.jagratjantanews.com/api/AdvertiseCategory/MiddleBottom`)
        setAd3( add2.data.AdvertisePath)
        const addbottom = await axios.get(`https://panel.jagratjantanews.com/api/AdvertiseCategory/Bottom`)
        setAdBottom( addbottom.data.AdvertisePath)
        const cat2 = r.data.NewsList.map((c,i)=>
        {
          if(props.subCat===undefined)
          {
            s=c.NewsType
          }
          else{
            s=props.subCat
          }
         if(i===0)
         {
          
         a= <Bg key={i}cat={props.catName} sub={s} href={c.Url}title={c.Title} img={c.CoverImage} fName={c.CreatedByFirstName}mName= {c.CreatedByMiddleName} lName={c.CreatedByLastName} date={c.CreatedOn}/>
         } 
         else if(i>=1 && i<=2)
         {   
          a=<Last key={i} cat={props.catName} sub={s}src={c.CoverImage}  heading={c.Title} href={c.Url}/>
          
         }
         else{
           a=null
         }
         return a
        });
        setReNews(cat2)
   
        if(props.subCat===undefined)
        {
          
          const res = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.catName}`)
        }
          else{ 
          const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/GetBySubCategory?url=${props.subCat}`)
        }
      } 
     
      getData();  
    },[]);}catch(err)
    {
      console.log(err)
    }

    const dis = useMediaQuery({ query: '(max-width: 1300px)' })
    const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
    return (
        <div>
            {isTabletOrMobile && <Container fluid={true} style={{paddingRight:"90px",paddingLeft:"90px"}}>
                  <CatTop CatName={props.catName} subCat={props.subCat}/>
                   <CatContainer1 name={props.catName} subCat={props.subCat}/>
                   <Row><Col sm="8"> 
                    <CatContainer2 catName={props.catName} subCat={props.subCat}/>
                    </Col>
                        <Col sm="4">
                        <Heading value1="Stay Connected"/>
                        <ColordIcon/>
                        <Ad ad={ad2}/>
                       <Heading value1="Recent News"/>
                      {reNews}
                       <Ad ad={ad3}/>
                       </Col>
                       
                    </Row>
                    
                  
                
            </Container>
            }
           {dis &&  <Container fluid={true} style={{marginTop:"52px"}} >
          {/* <CatTop CatName={props.catName}subCat={props.subCat} />*/}
           <CatContainer1 name={props.catName} subCat={props.subCat}/>
           <Row>
           <Col sm="8"> 
           <CatContainer2 catName={props.catName} subCat={props.subCat}/>
           </Col>
                        <Col sm="4">
                        <Heading value1="Stay Connected"/>
                        <ColordIcon/>

                       <Heading value1="Recent News"/>
                      {reNews}
                       </Col>
                    </Row>
       </Container>}
        </div>
    )
}
export default Cat;