import React from "react"
import Cat from './Cat'
import { Helmet } from 'react-helmet';
const Category=(props)=>
{ 
 {   /*let subCat;
     if(props.match.params.SubCat===false) 
    {
      let n = props.location.pathname.replace(/[\[\]?.,\/#!$%\^&\*;:{}=\\|_~()]/g, " ").split(" ");
 subCat=n[n.length - 1]
    }
    else{
       subCat=null;
 
    }*/
}
return(<div>
       <Helmet>
        <title>{props.match.params.catName} | Latest {props.match.params.catName} News Live | Breaking {props.match.params.catName} Live News Online – J.J.N.</title>
      </Helmet>
     <Cat catName={props.match.params.catName} subCat={props.match.params.SubCat}/>
    </div>)
}
export default Category;