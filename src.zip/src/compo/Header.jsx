import React from 'react';
import { Container} from 'reactstrap';
import TopHeader from './TopHeader';
import LogoHeader from './LogoHeader';
import FooterHeader from './FooterHeader';
import { makeStyles } from '@material-ui/core/styles';
import { useMediaQuery } from 'react-responsive';
import Test from './Test';
import SliderMenu from './SliderMenu';
function Header(){
    const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1200px)'})
    const disHeader = useMediaQuery({ query: '(max-width: 1200px)' })
   const useStyles = makeStyles({
        bg: {
            backgroundImage:"linear-gradient(#da4242,#8f0100)",
        },
      });
      const classes = useStyles();   
  return (
      <div>
          {isTabletOrMobile &&
    <Container className={classes.bg} fluid={true} >
      
      <TopHeader />

          </Container>}
          {isTabletOrMobile && <Container fluid={true} className="my-2">
              <LogoHeader/>
        
          </Container>}
          {isTabletOrMobile && <Container className={classes.bg} fluid={true}>
              <FooterHeader/>
        
          </Container>}
          {disHeader && <Test/>}
          {disHeader && 
         <Container style={{backgroundColor:"#dbdbdb",position:"fixed",top:"48px",zIndex:"1100"}} fluid={true}><SliderMenu/></Container> }
            
            <style>
                {
                    
                }
            </style>
           

    
    </div>
  );
}

export default Header;