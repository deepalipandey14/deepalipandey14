import React,{useState,useEffect} from 'react'
import { Row,Col} from 'reactstrap';
import Image from 'react-bootstrap/Image';
import LogoImg from '../images/logo.png'
import axios from 'axios';
import Ad from './Ad';
const LogoHeader=()=>{
  const [ad1, setAd1]= useState();
  try{
  useEffect(() => {
    async function getData1()
    {   const adTop = await (await axios.get(`https://panel.jagratjantanews.com/api/AdvertiseHome/Top`))
    setAd1(adTop.data.AdvertisePath)
  }
  getData1()
})}catch(err)
{
  console.log(err)
}
  return (
      <div className="px-5"> 
         <Row>
        <Col sm="3">
      <a href="/"><Image src={LogoImg} className="mx-3"/></a>
        </Col>
        <Col sm={9}className="adTop"> <Ad ad={ad1}  /></Col>
      </Row>
    </div>
  );
}

export default LogoHeader;