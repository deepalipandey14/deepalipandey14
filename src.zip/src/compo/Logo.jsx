import React from 'react';
import LogoImg from '../images/mobileLogo.png'
const Logo=()=>{
  return (
   
  <a href="/"><img src={LogoImg} alt="Logo"/></a>
      
  );
}

export default Logo;