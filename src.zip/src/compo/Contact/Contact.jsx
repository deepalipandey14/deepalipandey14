import React from 'react';
import { useMediaQuery } from 'react-responsive';
import ContactFrom from './ContactFrom';
import { Container, Row, Col } from 'reactstrap';
import CatTop from '../Categori/CatTop';
import Ad from '../Ad';
import ad4 from '../../images/ad4.png'
import {Typography,Divider } from '@material-ui/core';
import CommSideSection from '../CommSideSection';
const Contact=(props)=>
{
    const dis = useMediaQuery({ query: '(max-width: 1300px)' })
    const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
    return(<div>
       {isTabletOrMobile && <Container fluid={true} className="mb-4" style={{paddingRight:"90px",paddingLeft:"90px"}}><Row >   
            <Col sm="8">
            <CatTop CatName="Contact us"/>
            <Typography component="h5" variant="h4" style={{color:"#4c4c4ce6",fontWeight:"700"}} >Contact Us</Typography>
<Divider/>
<Typography component="h5" variant="body1" className="my-4"style={{color:"#f70d28"}} >At JJNnews we are always looking forward to hearing from you.</Typography>
            <Typography component="h5" variant="body1" className="my-4" style={{color:"#f70d28"}} >If you have any questions, comments, suggestions for us please send them to </Typography>
            <Typography  display="block"  className=" my-2" style={{fontSize:"22px",fontWeight:"500"}} >JJN News Network </Typography>
<Typography  display="block" className="h5">SMS us with your suggestions at 51818.</Typography>
<Typography  display="block"className="h5"><span className="font-weight-bold">HAlDWANI : </span> JJN NEWS CENTER, 301, Boston House, 3rd Floor, Suren Road,
Andheri - Haldwni- 263139.</Typography>
<Typography  display="block"className="h5"><span className="font-weight-bold">Phone  </span> 87489263139</Typography>
<Typography  display="block"className="h5"><span className="font-weight-bold">Fax No: </span> 0120-4070000- 111.</Typography>
<Typography  display="block"className="h5"><span className="font-weight-bold">Email: </span> deepalipandey86@gmail.com</Typography>
<Typography  display="block"className="6x my-3">JJNnews.com is a news, analysis, opinion and knowledge venture, launched in January 2021 by JJN (Jagrat Janta News) Media Solutions & Venture. We are headquartered in Haldwani (Uttarakhand), and are in the process of building a network across India because we believe in free, fair and questioning journalism. The team of JJNnews is committed to positive and meaningful use of digital media.However, before making a complaint viewers are encouraged to go through the Code of Ethics & Broadcasting Standards, News Broadcasting Standards (Disputes Redressal) Regulations and Guide to the Complaints Process. These details are available on the website of NBA</Typography>

<Typography display="block"className="h5 my-3"><span className="font-weight-bold">हल्द्वानी : </span> न्यूज नेटवर्क प्रा. लि.
</Typography>
<Typography display="block"className="h5"><span className="font-weight-bold">फैक्स: </span>  0120-4070000 एक्सटेंशन- 111.</Typography>
<Typography display="block"className="h5"><span className="font-weight-bold">फोन न.  </span>87489263139</Typography>
<Typography display="block"className="h5 "><span className="font-weight-bold">ई-मेल-फोन न.  </span>deepalipandey86@gmail.com</Typography>
<Divider className="my-5 "style={{height:"2px",backgroundColor:""}} />
<ContactFrom/>

            </Col>
            <Col sm="4">
               
              <CommSideSection/>
                <Ad ad={ad4}/>
                
                </Col>
        </Row> </Container>}




        {dis &&  <Container fluid={true} className="mb-4 mt-5">  <Row> 
        <Col sm="8">
          {/*  <CatTop CatName="Contact"/>*/}
            <Typography component="h5" variant="h5" style={{color:"#4c4c4ce6",fontWeight:"700"}} >Contact Us</Typography>
            <Divider/> <Typography component="h5" variant="h6" className="my-4"style={{fontSize:"16px",color:"#f70d28"}} >At JJNnews we are always looking forward to hearing from you.</Typography>
            <Typography component="h5" variant="h6" className="my-4" style={{fontSize:"16px",color:"#f70d28"}} >If you have any questions, comments, suggestions for us please send them to </Typography>
            <Typography  display="block" variant="h6" className="h3 my-3"  >JJN News Network </Typography>
<Typography variant="h6" display="block" className="h5">SMS us with your suggestions at 51818.</Typography>
<Typography variant="h6" display="block"className="h5"><span className="font-weight-bold">HAlDWANI : </span> JJN NEWS CENTER, 301, Boston House, 3rd Floor, Suren Road,
Andheri - East, Haldwni- 263139.</Typography>
<Typography variant="h6" display="block"className="h5 my-3">JJNnews.com is a news, analysis, opinion and knowledge venture, launched in January 2021 by JJN (Jagrat Janta News) Media Solutions & Venture. We are headquartered in Haldwani (Uttarakhand), and are in the process of building a network across India because we believe in free, fair and questioning journalism. The team of JJNnews is committed to positive and meaningful use of digital media.</Typography>
<Typography variant="h6" display="block"className="h5  my-3"><span className="font-weight-bold">हल्द्वानी: </span> न्यूज नेटवर्क प्रा. लि.
</Typography>
<Typography variant="h6" display="block"className="h5"><span className="font-weight-bold">फैक्स: </span>  0120-4070000 एक्सटेंशन- 111.</Typography>
<Typography variant="h6" display="block"className="h5"><span className="font-weight-bold">फोन न.  </span>0120 4070123</Typography>
<Typography variant="h6" display="block"className="h5"><span className="font-weight-bold">ई-मेल-फोन न.  </span>deepalipandey86@gmail.com</Typography>
<Divider className="my-5 "style={{height:"2px",backgroundColor:""}} />                      
<ContactFrom/>
            </Col>
            <Col sm="4">
            <CommSideSection/>
              <Ad ad={ad4}/>
               </Col>
        </Row></Container>} 
    </div>)
}
export default Contact;