import React from 'react';
import { Col, Row, Button, Form, FormGroup, Label, Input } from 'reactstrap';
const ContactFrom=(props)=>
{
    return(<div className="my-5">
        <Form >
      <Row form>
        <Col sm={6}>
          <FormGroup>
            <Label for="FirstName" className="font-weight-bold">First Name</Label>
            <Input type="name" name="fname"/>
          </FormGroup>
        </Col>
        <Col sm={6}>
          <FormGroup>
            <Label for="LastName"className="font-weight-bold">Last Name</Label>
            <Input type="name" name="lname" />
          </FormGroup>
        </Col>
      </Row>
      <FormGroup>
        <Label for="exampleAddress" className="font-weight-bold">Email</Label>
        <Input type="email" name="email"/>
      </FormGroup>
      <FormGroup>
        <Label for="Subject" className="font-weight-bold">Subject</Label>
        <Input type="text" name="Subject"/>
      </FormGroup>
      <FormGroup>
        <Label for="exampleText" className="font-weight-bold my-3 text-secondary">Message</Label>
        <Input type="textarea" name="text" style={{minHeight:"220px"}} />
      </FormGroup>
      <Button>Submit</Button>
    </Form>
    </div>)
}
export default ContactFrom ;