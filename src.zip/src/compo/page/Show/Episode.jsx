import React,{useEffect,useState} from 'react';
import {Container, Row, Col} from 'reactstrap';
import {Typography } from '@material-ui/core';
import CardContent from '@material-ui/core/CardContent';
import { makeStyles } from '@material-ui/core/styles';
import { useMediaQuery } from 'react-responsive';
import Media from '../../Home/Media';
import axios from 'axios';
import CatTop from '../../Categori/CatTop';
import OthEpilist from '../../../compo/Episode';
import {useParams} from "react-router-dom";
const useStyles = makeStyles((theme) => ({
    root: {
      display: 'flex!important',
      margin:"10px 0",
    },
    details: {
      display: 'flex',
      flexDirection: 'column',
      maxWidth:'100%',
  
    },
    content: {
      flex: '1 0 auto',
    },
   mediaContant:{
       maxWidth:'30%',
       flex: 'auto',
   },
   fonth:
   {
       fontWeight:'bold',
       height:48,
       overflow:'hidden',
   },
  
  }));
  
const EpiList=(props)=>
{ 
    const classes = useStyles();
    const epiUrl =useParams();
    const dis = useMediaQuery({ query: '(max-width: 700px)' })
const isTabletOrMobile = useMediaQuery({ query: '(min-width: 700px)' })
const [Epi1, setEpi1]=useState()
const [otherEpim,setOtherEpim] =useState();
const [otherEpi,setOtherEpi] =useState();
const [name, setName] =useState()
const [url, setUrl]=useState()
const [surl, setSUrl]=useState()
try{
useEffect(() => {
 
    async function getData()
    {
        
        const res = await axios.get(`https://panel.jagratjantanews.com/api/Episode/GetByShow?url=${epiUrl.Epi}`)
        setUrl("Shows")
     setSUrl(res.data.SEOTitle)
        setName( res.data.SEOTitle)
        res.data.EpisodeList.map((c,i)=>
            {
                if(i<10)
                {
                    if(i===0)
                    {
                        setEpi1(<> <div className="embed-responsive embed-responsive-16by9 " style={{height:"400px"}}>
                         <Media url={c.VideoUrl}/>
                      </div>
                      <div className={classes.details}>
          <CardContent className={classes.content}><Typography style={{fontSize:"20px",color:"#000000ba"}} component="h5" variant="h5" className={classes.fonth}>
          Ep. {c.Id}  {c.EpisodeTitle}
                                      </Typography> <Typography style={{fontSize:"18px"}} component="h5" variant="h5" className={classes.fonth}>
                       {c.Description}
                                      </Typography><Typography component="span" className="small mx-1 "style={{color:"#0000008c"}} variant="h6">
                                      {c.CreateTime} {c.CreateDate}</Typography></CardContent></div>
                                    
                                     </>)
                    }
                    else
                    {
                         setOtherEpi (<Col sm={6}xs={12}md={3}className="pt-2 " key={i} >
                        <Media url={c.VideoUrl}/>   <div className={classes.details}>
          <CardContent className={classes.content}><Typography style={{fontSize:"20px",color:"#000000ba"}} component="h5" variant="h5" className={classes.fonth}>
          Ep. {c.Id}  {c.EpisodeTitle}
                                      </Typography> <Typography style={{fontSize:"18px"}} component="h5" variant="h5" className={classes.fonth}>
                       {c.Description}
                                      </Typography>
                                      <Typography component="span" className="small mx-1 "style={{color:"#0000008c"}} variant="h6">
                     {c.CreateTime} {c.CreateDate}</Typography></CardContent></div>
                                  </Col>)
                                  setOtherEpim(<Col key={c.Id}  sm="12"lassName="pt-2 "  >
                                  <OthEpilist  date={c.CreateDate} time={c.CreateTime}Id={c.Id} heading={c.EpisodeTitle} src={c.VideoUrl} des={c.Description}/>
                                   </Col>)
                       
                    }
                } 
            }) 
           
    }getData()
})}catch(err)
{
  console.log(err)
}
    return (
        <div>
        {isTabletOrMobile &&<Container fluid={true}style={{paddingRight:"90px",paddingLeft:"90px"}}>
        <CatTop CatName={url} subCat={surl}/>
          <Row> 
          <Typography style={{fontSize:"25px",color:"#bd2929"}} component="h5" variant="h5" className="m-2 pl-2 py-2 font-weight-bold">
          {name}
                                      </Typography>
         </Row>
         <Row>
              {Epi1}
     
              </Row >
            
             <Row>
         {otherEpi} 
             
         </Row >
            
            </Container>}
            {dis &&  <Container>
                <CatTop CatName={url} subCat={surl}/>
                <Row className="px-2">
          <Typography style={{fontSize:"20px"}} component="h5" variant="h5" className="my-2 text-weight-bold">
          {name}
           </Typography>
           </Row>
            <Row className="px-2"> 
          {Epi1}
              </Row >
              <Row className="my-3">
                   {otherEpim} 
              </Row> 
            
                </Container>}         
        </div>
    )

}
export default EpiList;