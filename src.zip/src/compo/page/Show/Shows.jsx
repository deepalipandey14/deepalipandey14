import React,{useEffect,useState} from 'react';
import { useMediaQuery } from 'react-responsive';
import CatTop from '../../Categori/CatTop';
import {Row,Col,Container} from 'reactstrap';
import axios from 'axios';
import ShowCard from './ShowCards';

const Shows=(props)=>
{
    const dis = useMediaQuery({ query: '(max-width: 1300px)' })
const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })

const [Show, setShow]=useState();
 try{
      useEffect(() => {
      async function getData()
      {let a
          const res = await axios.get(`https://panel.jagratjantanews.com/api/Show/GetAll`)
          const cat = res.data.ShowList.map((c,i)=>
          {
           
        a= i<10 ?<Col xs={12} sm={4}md={3}>
            <ShowCard  key={i} title={c.Title} date={c.Date} time={c.Time}img={c.ImagePath} showname={c.Url} des={c.Description}/>
          </Col>:null
            return a
          })
          setShow(cat)
      } 
    
      getData();  
    },[]);}catch(err)
    {
      console.log(err)
    }
    return(
        <div>
            {isTabletOrMobile &&  <Container fluid={true} style={{paddingRight:"90px",paddingLeft:"90px"}}>
                  <CatTop CatName="Shows" />
                  
           <Row className="py-2 pb-4">
                   {Show}
           </Row>
           
             
                  </Container>
             }
            {dis && <Container fluid={true} >
                  <CatTop CatName="Shows"/>
                 
                  <Row className="py-2 pb-4">
                  {Show}
           </Row>
                  </Container>}
        </div>
    )
}
export default Shows;








