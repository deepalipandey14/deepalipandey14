import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
//import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import Link from '@material-ui/core/Link';
const useStyles = makeStyles({
    root: {
      marginTop:15,  
    },
  });
  
const ShowCards=(props)=>{
 
    const classes = useStyles();
    return (
      <Link href={`/Shows/${props.showname}`} className="text-decoration-none" >
<Card className={classes.root} >
      <CardActionArea >
        <CardMedia
          component="img"
          height="140"
          alt="Shows"
          //href={props.href}
          src={props.img} 
        />
        <CardContent>
          <Typography variant="body1"  component="p"className="font-weight-bold"style={{overflow:"hidden",maxHeight:"35px",minHeight:"35px",color:"#0000008c"}}>
        {props.title}
          </Typography>
          <Typography variant="body2" component="p" className="small my-2 pb-2 " style={{maxHeight:"59px",overflow:"hidden",minHeight:"59px",color:"#0000008c"}}>
              {props.des}
</Typography> 
        </CardContent>
      </CardActionArea>
    
    </Card>
    </Link>
    )
}
export default ShowCards;