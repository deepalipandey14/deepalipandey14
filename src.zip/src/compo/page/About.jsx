import React from 'react';
import CatTop from '../Categori/CatTop'
import {Container ,Row,Col} from 'reactstrap';
import { useMediaQuery } from 'react-responsive';
import { Typography, Divider } from '@material-ui/core';
import CommSideSection from '../CommSideSection';
import Section4 from '../Home/Section4'
const About=(props)=>
{console.log(props)
    const dis = useMediaQuery({ query: '(max-width: 1300px)' })
    const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
    return(
        <div>
            
            {isTabletOrMobile && <Container fluid={true} className="mb-4" style={{paddingRight:"90px",paddingLeft:"90px"}}>
            <Row><Col sm="8"><CatTop CatName="About Us"/>
           
            <Typography component="h5" variant="h4" style={{color:"#4c4c4ce6",fontWeight:"700"}} >About Us</Typography>
            <Divider/> <Typography conponant="span" className="my-3">
            JJNnews.com is a news, analysis, opinion and knowledge venture, launched in January 2021 by JJN (Jagrat Janta News) Media Solutions & Venture. We are headquartered in Haldwani (Uttarakhand), and are in the process of building a network across India because we believe in free, fair and questioning journalism. The team of JJNnews is committed to positive and meaningful use of digital media.
           </Typography>
          <Section4 name="uttarakhand" fv="1" lv="2"/></Col>
            <Col sm="4">
                <CommSideSection/>
                </Col></Row>
               
            </Container>}
         
             {dis && <Container fluid={true} className="mb-4 mt-5 pt-4">
            <Row><Col sm="8">{/*<CatTop CatName="About Us"/>*/}
            <Typography component="h5" variant="h5" style={{color:"#4c4c4ce6",fontWeight:"700"}} >About Us</Typography>
            <Divider/><Typography conponant="span" className="my-3">
            JJNnews.com is a news, analysis, opinion and knowledge venture, launched in January 2021 by JJN (Jagrat Janta News) Media Solutions & Venture. We are headquartered in Haldwani (Uttarakhand), and are in the process of building a network across India because we believe in free, fair and questioning journalism. The team of JJNnews is committed to positive and meaningful use of digital media.
         
            </Typography>
          
            </Col>
            <Col sm="4"> 
            <CommSideSection/>
                </Col></Row>
            </Container>}
        </div>
    )
}
export default About;