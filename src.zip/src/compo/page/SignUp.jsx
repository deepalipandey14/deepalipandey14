
import { makeStyles } from '@material-ui/core/styles';
import {
    Card, CardText, CardBody, CardLink, CardSubtitle, Button
  } from 'reactstrap';
  import React,{useEffect,useState} from 'react';
import {useHistory} from 'react-router-dom';
  import logo from '../../images/sLogo.png';
  import google from '../../images/google.png';
  import Image from 'react-bootstrap/Image';
import { Divider, Typography } from '@material-ui/core';
import { Form, FormGroup, Label, Input,Col,Row} from 'reactstrap';
import axios from 'axios';
  const useStyles = makeStyles(
      {
          crd:
          {textAlign:"center",
              margin:"auto",
            width: "fit-content",
            borderBottomWidth:"thick",
          
          }
      }
  )
const SignUp=(props)=>{


  const classes = useStyles(); 
  const [email,setEmail]=useState("")
  const [password,setPassword]=useState("")
  const [name,setName]=useState("")
  const [state,setState]=useState("")
  
    return(<div className="p-4"style={{backgroundColor:"#bef1f13f"}}>
    
        <Card className={classes.crd}>
          <CardBody>
          <Image src={logo} className="" style={{maxWidth:"100%"}}/>
            <CardSubtitle className="my-2 text-muted"style={{fontSize:"18px",color:"#424a50"}} > Sign Up by</CardSubtitle>
            <Button style={{backgroundColor:"#f1f1f1",border:"1px solid #ddd",color:"#393838",fontSize:"18px",padding:"5px 20px",textAlign:"center"}} ><Image src={google} className="mr-2"/> Google</Button>
            <CardText style={{fontSize:"20xpx"}}>OR</CardText>
            <Divider/>
            <CardSubtitle className="my-2 "style={{fontSize:"18px",color:"#424a50"}}> Sign Up by your Email id / Mobile No.</CardSubtitle>
        
            <Form className="mt-4" action="/component/" method="POST">
      <Row form>
        <Col md={6}>
          <FormGroup>
            <Input type="name" name={name} id="" placeholder="Enter your full Name" onChange={(e)=> setName(e.target.value)}/>
            
          </FormGroup>
        </Col>
        <Col md={6}>
          <FormGroup>
            <Input type="select" name={state} id="exampleSelect" onChange={(e)=> setState(e.target.value)} >
          <option>state</option>
          <option>uttarakhand</option>
          <option>uttarPardesh</option>
          <option>kkjsdhgjskk</option>
          <option>5</option>
        </Input>
          </FormGroup>
        </Col>
      </Row>
      <Row form>
        <Col md={6}>
         <FormGroup>
            <Input type="email" name={email} id="" placeholder="Enter your Email/Mobile no." onChange={(e)=> setEmail(e.target.value)}/>
        </FormGroup>
        </Col>
        <Col md={6}>
          <FormGroup>
            <Input type="password" name={password} id="examplePassword" placeholder="Enter your password" onChange={(e)=> setPassword(e.target.value)}/>
          </FormGroup>
        </Col>
      </Row>
      <FormGroup check style={{textAlign:"start" ,maxWidth:"fit-content"}}> 
        <Input type="checkbox" name="check" id="exampleCheck"/>
        <Label for="exampleCheck" check>I agree to the processing of my personal info. for profiling such as My Credits, Follow activity and Advertisements. </Label>
      </FormGroup>
      <FormGroup check style={{textAlign:"start",maxWidth:"fit-content"}}> 
        <Input type="checkbox" name="check" id="exampleCheck"/>
        <Label for="exampleCheck" check>I wish to receive custom communications i.e. Emails, newsletters, SMS, notifications from JJN based on my interests and my activities. </Label>
      </FormGroup>
      <Button color="primary"className="my-3" >Sign Up</Button>{/*onClick={signUp} */}
    </Form>
    <Typography> Already SignUp ?</Typography>
            <CardLink href="/Login/">Login</CardLink>
          </CardBody>
        </Card>
       
      </div>)
}
export default SignUp;