import React from 'react'
const Img=(props)=>
{
    return (<div>

    </div>)
}
export default Img;