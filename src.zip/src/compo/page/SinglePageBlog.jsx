import React,{useState,useEffect} from 'react'
import CatTop from '../Categori/CatTop';
import { useMediaQuery } from 'react-responsive';
import {Container,Row,Col,Media} from 'reactstrap';
import { Divider, Link, Typography } from '@material-ui/core';
import CommentIcon from '@material-ui/icons/Comment';
import {Button  }from '@material-ui/core';
import FacebookIcon from '@material-ui/icons/Facebook';
import TwitterIcon from '@material-ui/icons/Twitter';
import WhatsAppIcon from '@material-ui/icons/WhatsApp';
//import LinkedInIcon from '@material-ui/icons/LinkedIn';
import { makeStyles } from '@material-ui/core/styles';
import { Markup } from 'interweave';
//import MetaTags from 'react-meta-tags';
//import { FormGroup, Label, Input } from 'reactstrap';
import {FacebookShareButton,TwitterShareButton,WhatsappShareButton} from "react-share";
import Heading from '../Home/Heading';
import NewDiv from '../Home/NewDiv';
import Ad from '../Ad';
import Image from 'react-bootstrap/Image';
import editor from '../../images/editor.png';
import ShareIcon from '@material-ui/icons/Share';
import BookmarkBorderIcon from '@material-ui/icons/BookmarkBorder';
import axios from 'axios';
//import {ReactTitle} from 'react-meta-tags';
import Helmet from './Helmet'
import Last from '../Home/Last';
//import DOMPurify from "dompurify";
const useStyles = makeStyles({
    iconSize: {
      fontSize:19,
      margin:"0px 5px" 
    },
  });
const SinglePageBlog=(props)=>{  
{  /*  const shareButtonProps = {
        url: "https://github.com/greglobinski/react-custom-share",
        network: "Facebook",
        text: "Give it a try - react-custom-share component",
        longtext:
          "Social sharing buttons for React. Use one of the build-in themes or create a custom one from the scratch."
      };*/}
    const classes = useStyles();  
    const dis = useMediaQuery({ query: '(max-width: 1300px)' })
    const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
    const [update, setUpdates]=useState();
    const [pre, setPre]=useState();
    const [next, setNext]=useState();
    const [tag, setTag]=useState();
    const [nextLink,  setNextLink]=useState();
    const [preLink,  setPreLink]=useState();
    const [localUpdate, setLocalUpdate]=useState();
    const [topSection, setTopSection] = useState(); 
    const [ad2, setAd2]= useState();
    const [ad3, setAd3]= useState(); 
    const [adBottom, setAdBottom]= useState();
 {/*   function dec()
    { 
  
        return { __html: `${props.newsValue2}`}
        }*/} 
  
    useEffect(() => {
        try{
        if (props.cat==="Live" ||props.cat==="Breaking"|| props.cat==="Updates")
        {
            setTopSection(<CatTop CatName={props.cat}/>)
            async function getData1(){
                const add1 = await axios.get(`https://panel.jagratjantanews.com/api/AdvertiseDetails/MiddleTop`)
                setAd2( add1.data.AdvertisePath)
                    const add2 = await axios.get(`https://panel.jagratjantanews.com/api/AdvertiseDetails/MiddleBottom`)
                    setAd3( add2.data.AdvertisePath)
                    const addbottom = await axios.get(`https://panel.jagratjantanews.com/api/AdvertiseDetails/Bottom`)
                    setAdBottom( addbottom.data.AdvertisePath)
            const res = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=uttarakhand`)
            const cat1 = res.data.NewsList.map((c1,i)=>
            {
                return i<=3?<Last src={c1.CoverImage}  heading={c1.Title} href={c1.Url} cat="uttarakhand" sub={c1.NewsType} />:null
            })
            setLocalUpdate(cat1)
        }
        getData1();
            
        }
        else
        {
         if(props.sub==="Story" || props.sub==="Photo" || props.sub==="Video")
         {  setTopSection(<CatTop CatName={props.cat}/>)
             async function getData1(){
            const r = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.cat}`)
            
            const cat1 = r.data.NewsList.map((c1,i)=>
            {
                return i<=3?<Last src={c1.CoverImage}  heading={c1.Title} href={c1.Url} cat={props.cat} sub={props.sub}/>:null
            }) 
             setLocalUpdate(cat1)
            }
            getData1()
         }  
         else{
            setTopSection(<CatTop CatName={props.cat} subCat={props.sub}/>)
            async function getData1(){
                const r = await axios.get(`https://panel.jagratjantanews.com/api/News/GetBySubCategory?url=${props.sub}`)
                    
                const cat1 = r.data.NewsList.map((c1,i)=>
                {
                    return i<=3?<Last src={c1.CoverImage}  heading={c1.Title} href={c1.Url} cat={props.cat} sub={props.sub}/>:null
                }) 
                 setLocalUpdate(cat1)
                }
                getData1()

         } 
        }
        async function getData()
        {  
            let a,p,n;
            
            const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/AllNews`)
            const res2= await axios.get(`https://panel.jagratjantanews.com/api/News/GetDetails?url=${props.parurl}`)
           
            const t= res2.data.TagList.map((c,i)=>
            { 
               return <Link key={i} href="#" style={{textDecoration:"none"}}><Typography component="span" style={{backgroundColor:"#8080800f",padding:"0.2em",marginLeft:"8px",color:"black"}} >{c.Name}</Typography>
           </Link> 
            })
            setTag(t)
        
    
            const ne = res1.data.NewsList.map((c,i)=>
            { 
                if(props.Id===c.Id)
                {
                    if(i===0)
                    {
                        p=i;
                        n=i+1;  
                        console.log(res1.data.NewsList[n].Title)
                    }
                    else if(i===res1.data.NewsList.length-1)
                    {
                        n=i
                        p=i-1; 
                    }
                    else{
                    p=i-1;
                    n=i+1;
                 
                    }
                    setNext(res1.data.NewsList[n].Title);
                    setPre(res1.data.NewsList[p].Title);
                    setNextLink(res1.data.NewsList[n].Url);
                    setPreLink(res1.data.NewsList[p].Url);
                   
                }
             
           
              if(i<6)
              {
                  
                  a=<NewDiv key={c.Id} sub={c.NewsType} cat="Updates" href={c.Url}value={c.Title} />
    
              }
              else
              {
                  a=null
              }
                return a
                
            })
              setUpdates(ne) 
              
             }      
        getData();
        
            }catch(err)
            {
                console.log(err)
            }    
    },[]);

    return (
        <div>
           
{ /*     <MetaTags>
   
            <meta name="description" content="Some description." />
            <meta property="og:title" content="MyApp" />
            <meta property="og:image" content="path/
            to/image.jpg" />
</MetaTags>  */} 
            {isTabletOrMobile && <Container fluid={true}style={{paddingRight:"90px",paddingLeft:"90px"}}>
            <Row>
                <Col sm="8">
                    <div className="mb-3">
                        {topSection}
               
                <Typography  component="h4" variant="h4" className="my-2">{props.title}</Typography>
                <Image src={editor} className="text-secondary mr-1"roundedCircle />
                <span className="text-secondary mx-1">by</span>
                <Typography className="text-danger mx-1 font-weight-bold " component="span"   variant="h6"> {props.fName} {props.mName} {props.lName} 
                </Typography> 
                <Typography component="span" className="small mx-1 "style={{color:"#0000008c"}} variant="h6">
                    -  {props.date}</Typography> 
                    </div>
        <Media src={props.src} alt="Generic placeholder image" style={{width:"100%",maxHeight:"500px",objectFit:"cover"}} />
      <div className="my-3">
 {/*<span style={{fontSize:"20px"}} className="font-weight-bold"> {props.view} /</span>  <span style={{fontSize:"16px",padding:"0px 8px"}}>Views</span>*/} 
<Button variant="contained" style={{backgroundColor:"#45629f",color:"white"}}className="mx-1 px-1 py-0">
<FacebookShareButton 
            url="https://testing.ascentrek.co.in/"
                quote={"Jagrit Janta Network News"}
                hashtag="#JJN"
LineShareButton="aamir-khan-said-goodbye-to-social-media-125611-2021-03-16"property="og:title=bgdhhhhhhhhhhhhhhhgloooooooooooo"> 
  
  Facebook    <FacebookIcon  className={classes.iconSize} /></FacebookShareButton>
</Button>
<Button variant="contained"style={{backgroundColor:"#5eb2ef",color:"white"}}className="mx-1 px-1 py-0">
<TwitterShareButton
            url="https://testing.ascentrek.co.in"
                quote={"Jagrit Janta Network News"}
                hashtag="#JJN"
LineShareButton="aamir-khan-said-goodbye-to-social-media-125611-2021-03-16"> 
  
  Twitter    <TwitterIcon  className={classes.iconSize} /></TwitterShareButton>
</Button>


<Button variant="contained"style={{backgroundColor:"#075e54",color:"white"}}className="mx-1 px-1 py-0">
<WhatsappShareButton
     url={"https://testing.ascentrek.co.in"}
     quote={"CampersTribe - World is yours to explore"}
     hashtag="#camperstribe"
   >Whatsapp<WhatsAppIcon   className={classes.iconSize}/></WhatsappShareButton>
</Button>
{/*<Button variant="contained" style={{backgroundColor:"#08c",color:"white"}} href="#contained-buttons"className="mx-1 px-1 py-0">
LinkedIn<LinkedInIcon className={classes.iconSize}/>
</Button>*/} <div className="float-sm-right">
<CommentIcon className="text-danger mx-2"/>
<ShareIcon className=" mx-2 " style={{color:"#29272799"}}/>
<BookmarkBorderIcon className=" mx-2"style={{color:"steelblue"}}/></div>
<Typography component="span"variant="h6" className="text-secondary my-3 "style={{fontSize:"1rem",display:"block"}}>
{props.newsValue} 
</Typography>

<Typography component="span"variant="h6" className="text-secondary my-3"style={{fontSize:"1rem",display:"block"}}  >
<Markup content={props.newsValue2}/></Typography> 
{/*<Typography component="span"variant="h6" className="text-secondary my-3"style={{fontSize:"1rem"}} dangerouslySetInnerHTML={dec()} ></Typography> 
<Typography component="span"variant="h6" className="text-secondary my-3"style={{fontSize:"1rem"}} dangerouslySetInnerHTML={{__html: DOMPurify.sanitize(`${props.newsValue2}`)}} ></Typography> 
*/}


</div>
<Divider />
<Typography component="span"variant="h6"className="mt-2" >
    Tags:{tag}
</Typography>
<div className="border-top border-bottom my-2">

<Row>
    <Col sm="6" >
        <Typography component="span"variant="h6" style={{fontWeight:"bolder",color:"#a0a0a0",display:"block"}}>
        Previous Post 
        </Typography>
        <Link href={`/${props.cat}/${props.sub}/${nextLink}`} style={{textDecoration:"none"}}>  <Typography component="span"variant="span" style={{fontWeight:"900",color:"#000000a8",display:"block",margin:"15px 0px",paddingLeft:"7px",borderLeft:"5px gray solid"}}>
      {next}
        </Typography> </Link>
    </Col>
    <Col sm="6" >
    <Typography component="span"variant="h6" style={{fontWeight:"bolder",color:"#a0a0a0",display:"block"}}>
  
Next Post
</Typography>
<Link href={`/${props.cat}/${props.sub}/${preLink}`} style={{textDecoration:"none"}}>  
<Typography component="span"variant="span" style={{fontWeight:"900",color:"#000000a8",margin:"15px 0px",paddingLeft:"7px",borderLeft:"5px gray solid",display:"block"}}>
  {pre}
        </Typography></Link>
</Col>
</Row >

</div>
     <Divider className="my-4" />
 { /*   <Typography component="h6" variant="h6" className="font-weight-bold">
         Leave a Reply
     </Typography>
     <Typography component="span" variant="span"style={{color:"#f70d28"}}>
         Logged in as JJN News. Log out ?
     </Typography>
     <FormGroup>
        <Label for="exampleText" className="font-weight-bold my-3 text-secondary">Comments</Label>
        <Input type="textarea" name="text" id="exampleText"style={{minHeight:"170px"}}/>
      </FormGroup>
      <FormGroup>
      <Button variant="contained" style={{backgroundColor:"#f70d28d4",color:"white"}}className="font-weight-bold">
  Post Comments
</Button>
    </FormGroup>*/}
        
                </Col>
                
                <Col sm="4">
                    
                    <Heading value1="Popular" value2="News"/>
    {update} 
<Ad ad={ad2}/>
        
   { /*    <ButtonGroup color="secondary" aria-label="outlined primary button group" className="my-4">
  <Button>Trending</Button>
  <Button>Comments</Button>
  <Button>LAtest</Button>
    </ButtonGroup>*/}
{localUpdate}<Ad ad={ad3}/>
                </Col>
            </Row>
            </Container>}
            {dis &&  <Container fluid={true} style={{marginTop:"64px"}} >
            <Row>
            <Col sm="8">
                    <div className="my-3">
                    {/*{topSection}*/}
                <Typography  component="h4" variant="h5" className="my-2">{props.title}</Typography>
                <Image src={editor} className="text-secondary mr-1"roundedCircle /> 
                <span className="text-secondary mx-1">by</span>
                <Typography className="text-danger mx-1 font-weight-bold" component="span"   variant="h6"> {props.editorName} 
                </Typography> 
                <Typography component="span" className="small mx-1"style={{color:"#0000008c"}} variant="h6">
                    -  {props.date}</Typography> 
                    </div>
        <Media src={props.src} alt="Generic placeholder image" style={{width:"100%"}} />   
      <div className=" my-3">
     {/* <span style={{fontSize:"20px"}} className="font-weight-bold"> {props.view} /</span>
        <span style={{fontSize:"16px",padding:"0px 5px"}}>Views</span>*/ }
      <Button variant="contained" style={{backgroundColor:"#45629f",color:"white"}}className="mx-1 px-1 py-0">
Facebook<FacebookIcon  className={classes.iconSize} />
</Button>
<Button variant="contained"style={{backgroundColor:"#075e54",color:"white"}}className="mx-1 px-1 py-0">
Whatsapp<WhatsAppIcon   className={classes.iconSize}/>
</Button>
{/*<Button variant="contained" style={{backgroundColor:"#08c",color:"white"}} href="#contained-buttons"className="mx-1 px-1 py-0">
LinkedIn<LinkedInIcon className={classes.iconSize}/>
    </Button>*/}
<CommentIcon className="text-danger mx-2"/>
<ShareIcon className=" mx-2 " style={{color:"#29272799"}}/>
<BookmarkBorderIcon className=" mx-2"style={{color:"steelblue"}}/></div><div className="my-3">
<Typography component="span"variant="h6" className="text-secondary my-3 "style={{display:"block"}}>
{props.newsValue}
</Typography>
<Typography component="span"variant="h6" className="text-secondary my-3"style={{fontSize:"1rem",display:"block"}} dangerouslySetInnerHTML={{__html: `${props.newsValue2}`}} />
</div>
<Divider />
<Typography component="span"variant="h6"className="mt-2" >
    Tags:{tag}
</Typography>
<div className="border-top border-bottom my-2">
<Row>
    <Col sm="6" className="border-right">
        <Typography component="span"variant="h6" style={{fontWeight:"700",color:"#a0a0a0",display:"block"}}>
        Previous Post
        </Typography><Link href={`/${props.cat}/${props.sub}/${nextLink}`} style={{textDecoration:"none"}}>
        <Typography component="span"variant="h6" style={{display:"block",fontWeight:"900",color:"#000000a8",margin:"15px 0px"}}>
       {next}
        </Typography>
        </Link>
    </Col>
    <Col sm="6" >
    <Typography component="span"variant="h6" style={{fontWeight:"700",color:"#a0a0a0",display:"block"}}>
Next Post
</Typography>
<Link href={`/${props.cat}/${props.sub}/${preLink}`} style={{textDecoration:"none"}}>
<Typography component="span"variant="h6" style={{fontWeight:"900",color:"#000000a8",margin:"15px 0px",display:"block"}}>
        {pre}
        </Typography></Link>
</Col>
</Row>

</div>
     
<Divider className="my-4" />
     {/*<Typography component="h6" variant="h6" className="font-weight-bold">
         Leave a Reply
     </Typography>
     <Typography component="span" variant="span"style={{color:"#f70d28"}}>
         Logged in as JJN News. Log out ?
     </Typography>
     <FormGroup>
        <Label for="exampleText" className="font-weight-bold my-3 text-secondary">Comments</Label>
        <Input type="textarea" name="text" id="exampleText"style={{minHeight:"170px"}}/>
      </FormGroup>
      <FormGroup>
      <Button variant="contained" style={{backgroundColor:"#f70d28d4",color:"white"}}className="font-weight-bold">
  Post Comments
</Button>
</FormGroup>*/}
        
        
                </Col>
                <Col sm="4">
                      
                <Heading value1="Popular" value2="News"/>
            
            {update}
               
        
        <Ad ad={ad2}/>
                
          {  /*    <ButtonGroup color="secondary" aria-label="outlined primary button group" className="my-4">
          <Button>Trending</Button>
          <Button>Comments</Button>
          <Button>LAtest</Button>
    </ButtonGroup>*/}
        {localUpdate}
        
        <Ad ad={ad3}/> 
                </Col>
            </Row>
         
          </Container>}
          

<style>
    {
        `.MuiButton-label {
            font-size: 12px;
            padding: 6px;
            
        }
                `
    }
</style>
           
            
        </div>
    )
}
export default SinglePageBlog;