import { Link, Typography } from '@material-ui/core';
import UpdateIcon from '@material-ui/icons/Update';
const BgCompo=(props)=>{
    let s
    if(props.sub === "null")
    {
        s="Story"
    }
    else{
        s=props.sub
    }
    
    return(
<Link href={`/${props.cat}/${s}/${props.href}`}   className="text-decoration-none">
        <div  style={{backgroundImage: `url(${props.img})`, margin:"11px 0", backgroundRepeat:'no-repeat',minHeight:"290px",position:"relative"}} >
          <Typography className="font-weight-bolder text-white my-3 "style={{position:"absolute",left:"10px",right:"10px",bottom:"10px",overflow:"hidden",height:"40px"}}> 
          <Typography variant="body2" component="span" className=""style={{display:"block"}}>By
<Typography className="text-danger ml-1 font-weight-bold" component="span" variant="h6"> {props.fName} {props.mName} {props.lName}</Typography>
 <Typography component="span" className=" small text-white px-3  " style={{color:"#0000008c"}}variant="h6">
  <UpdateIcon style={{fontSize:"1rem"}}/> {props.date}</Typography></Typography>{props.title}
         
          </Typography>
 
          </div>
          </Link>
    )

}
export default BgCompo;