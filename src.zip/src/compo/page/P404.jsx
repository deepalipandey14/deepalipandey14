import React from 'react';
import { Container } from 'reactstrap';
import {  Link, Typography } from '@material-ui/core';
import { useMediaQuery } from 'react-responsive';
const P404 =(props)=>
{
    const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
    const dis = useMediaQuery({ query: '(max-width: 1300px)' })
    return(
        <div className="pb-5 mb-3">
       
          
      {dis &&   <Container className="text-center px-1 mt-2">  
      <Typography  component="h2"variant="h2" style={{fontSize:"1.75rem",lineHeight:"2rem",fontWeight:"700", paddingBottom:"0.5rem",color:"#B80000"}}>Error 404</Typography>

<Typography component="h5" variant="h4" style={{color:"#4c4c4ce6",fontWeight:"700"}} > Page cannot be found</Typography>
<Typography conponant="span" className="my-2" style={{fontSize:"17px"}}>
Sorry, we're unable to bring you the page you're looking for. Please try:
           </Typography>
         
       <Typography conponant="span" className="my-2 text-left" style={{fontSize:"17px"}}>
          <ul style={{lineHeight:"2em"}}><li>Double checking the url</li>
          <li> Hitting the refresh button in your browser</li>
          <li>  Searching for this page using the BBC search bar</li> </ul>
           </Typography><Typography conponant="span" className="my-2 " style={{fontSize:"17px"}}>
          Alternatively, please visit the <Link href="/">JJN News homepage.</Link>
           </Typography>
           </Container>}
           {isTabletOrMobile &&   <Container className="text-left" style={{padding:""}}>  
           <Typography  component="h2"variant="h2" style={{fontSize:"1.75rem",lineHeight:"2rem",fontWeight:"700", paddingBottom:"0.5rem",color:"#B80000"}}>Error 404</Typography>

<Typography component="h5" variant="h4" style={{color:"#4c4c4ce6",fontWeight:"700"}} > Page cannot be found</Typography>
<Typography conponant="span" className="my-2" style={{fontSize:"17px"}}>
Sorry, we're unable to bring you the page you're looking for. Please try:
           </Typography>
          <Typography conponant="span" className="my-2" style={{fontSize:"17px"}}>
           <ul style={{lineHeight:"3em"}}><li>Double checking the url</li>
          <li> Hitting the refresh button in your browser</li>
          <li>  Searching for this page using the JJN search bar</li> </ul>
           </Typography>
           <Typography conponant="span" className="my-2 " style={{fontSize:"17px"}}>
          Alternatively, please visit the <Link href="/">JJN News homepage.</Link>
           </Typography>
           </Container>}
          
          
          
        </div>
    )
}
export default P404;