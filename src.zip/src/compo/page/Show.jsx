import ShowList from './ShowList'
const Show=(props)=>
{ console.log(props)
    return (
        <div>
    <ShowList />
        </div>
    )
}
export default Show;