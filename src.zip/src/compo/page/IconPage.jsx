import React from 'react';
import ShareIcon from '@material-ui/icons/Share';
import BookmarkBorderIcon from '@material-ui/icons/BookmarkBorder';
import CommentIcon from '@material-ui/icons/Comment';
import { useMediaQuery } from 'react-responsive';
import {Container } from 'reactstrap';
const IconPage=(props)=>
{
    
    const dis = useMediaQuery({ query: '(max-width: 1300px)' })
    const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
    return (
    <Container className="d-flex ">
        {isTabletOrMobile && <div className="">
        <CommentIcon className="text-danger mx-2 "style={{fontSize:"1.3rem"}}/>
<ShareIcon className=" mx-2 " style={{color:"#29272799",fontSize:"1.3rem"}}/>
<BookmarkBorderIcon className=" mx-2"style={{color:"steelblue",fontSize:"1.3rem"}}/>
</div>}
{dis && <div  className="d-flex ">
        <CommentIcon className="text-danger mx-1 "style={{fontSize:"1.3rem"}}/>
<ShareIcon className=" mx-1" style={{color:"#29272799",fontSize:"1.3rem"}}/>
</div>}

</Container>)
}
export default IconPage;