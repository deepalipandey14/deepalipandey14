import React,{useEffect,useState} from 'react';
import {useHistory} from 'react-router-dom';
import { makeStyles } from '@material-ui/core/styles';
import {
    Card, CardText, CardBody, CardLink, CardSubtitle, Button
  } from 'reactstrap';
  import logo from '../../images/sLogo.png';
  import google from '../../images/google.png';
  import Image from 'react-bootstrap/Image';
import { Divider, Typography } from '@material-ui/core';
//import axios from 'axios';
import { Form, FormGroup, Label, Input,Col,Row} from 'reactstrap';
  const useStyles = makeStyles(
      {
          crd:
          {textAlign:"center",
              margin:"auto",
            width: "fit-content",
            borderBottomWidth:"thick",
          
          }
      }
  )

 
const Login=(props)=>
{const [email,setEmail]=useState("")
const [password,setPassword]=useState("")
const [userInfo,setUserInfo]=useState(
  {
    Name:"Amit",
EmailId:"amit@gmail.com",
GoogleId:"1234567809",
DeviceId:"0978563412",
DeviceToken:"1234",
DeviceType:"web",
  }
)
    const classes = useStyles();
    const history = useHistory();
    try{
    useEffect(() => {
      if(localStorage.getItem('user-info'))
      {
    //  history.push("/")
      }
    }, [])}catch(err)
    {
      console.log(err)
    }
    async function login()
    {
      
      let item={email,password}
      let result = await fetch(`https://panel.jagratjantanews.com/api/Account/Login?filter={"where":{"email":"${email}"}}`,{
        method:'POST',
        headers:{
        "Content-Type": "application/json; charset=utf-8",
       "Accept":"application/json, text/plain, */*"
      },
        body:JSON.stringify(item)});
        result= await result.json
        localStorage.setItem('user-info',JSON.stringify(result))
        console.log(result)
       history.push(
         {
           pathname:"/",
           search: `?query=${email}`,
        
        })

           
    }

    return(<div className="p-4"style={{backgroundColor:"#bef1f13f"}} >{/*style={{backgroundImage:"linear-gradient(to right, #ce9090, #ac4242)"}} */}
        <Card className={classes.crd}>
          <CardBody>
          <Image src={logo} className="" style={{maxWidth:"100%"}}/>
            <CardSubtitle className="my-2 text-muted"style={{fontSize:"18px",color:"#424a50"}} > Login Up by</CardSubtitle>
            <Button style={{backgroundColor:"#f1f1f1",border:"1px solid #ddd",color:"#393838",fontSize:"18px",padding:"5px 20px",textAlign:"center"}} ><Image src={google} className="mr-2"/> Google</Button>
            <CardText style={{fontSize:"20xpx"}}>OR</CardText>
            <Divider/>
            <CardSubtitle className="my-2 "style={{fontSize:"18px",color:"#424a50"}}> Login by your Email id / Mobile No.</CardSubtitle>
        
            <Form className="mt-4">
      <Row form>
     
        <Col md={12}>
          <FormGroup>
            <Input type="email" name="email" id="" placeholder="Enter your Email/Mobile no." onChange={(e)=>setEmail(e.target.value)}/>
          </FormGroup>
        </Col>
        <Col md={12}>
          <FormGroup>
            <Input type="password" name="password" id="examplePassword" placeholder="Enter your password"onChange={(e)=>setPassword(e.target.value)} />
          </FormGroup>
        </Col>
        <Col md={6}>
        <FormGroup check   style={{textAlign:"start" ,maxWidth:"fit-content"}}> 
        <Input type="checkbox" name="check" id="exampleCheck"/>
        <Label for="exampleCheck" check>Remember me </Label> 
      </FormGroup></Col><Col md={6}><CardLink className="float-right" href="#">Forgot Password?</CardLink>

      </Col> </Row>
     
      <Button color="primary"className="my-3" onClick={login}>Log in</Button>
    </Form>
    <Typography> Not register yet ?</Typography>
            <CardLink href="/SignUp/">Register Here!</CardLink>
          </CardBody>
        </Card>
    
      </div>)
}
export default Login;