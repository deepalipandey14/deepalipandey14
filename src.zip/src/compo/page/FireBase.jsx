import firebase from'firebase';
var firebaseConfig = {
    apiKey: "AIzaSyBV-mm9HZllK2nmnpa-dl1P6zK1wI-7Ws0",
    authDomain: "jjn-project.firebaseapp.com",
    projectId: "jjn-project",
    storageBucket: "jjn-project.appspot.com",
    messagingSenderId: "667878708983",
    appId: "1:667878708983:web:592aae509c2372cfcfa5f2"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
export default firebase;