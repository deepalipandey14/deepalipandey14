import React, {useState,useEffect} from "react"
import Searching from '../../compo/SearchingPage';
import { useMediaQuery } from 'react-responsive';
import {Container, Row, Col} from 'reactstrap';
import {Input } from 'reactstrap';
import SearchSharpIcon from '@material-ui/icons/SearchSharp';
import CatTop from "../Categori/CatTop";
import {Typography } from '@material-ui/core';
import axios from 'axios';
import { useHistory } from "react-router-dom";
import Link from '@material-ui/core/Link';
const Search=(props)=>
{
    let history = useHistory();
    const [searctNews, setSearchNews]=useState();
    const dis = useMediaQuery({ query: '(max-width: 1300px)' })
    const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
    const [resCount, setResCount]=useState();
    const[searchval, setSearchVal]=useState();

    const[searchResult, setSearchResult]=useState([]);
   
const searchN =( key)=>
{ 
    setSearchVal(key)
   
    try{
        if(searchval !=="")
        {
            
    async function getData()
    {  
         const res= await axios.get(`https://panel.jagratjantanews.com/api/Search/Get?SearchText=${key}`) 
    if(res.data.NewsList.length===0)
    {
       
        return <Typography>NO Result found!!</Typography>
    }
     
else{
 
    const cat = res.data.NewsList.map((c,i)=>
    { 
        if(i<10){
        return  <Searching key={i} heading={c.Title} src={c.CoverImage} href={c.Url} sub={c.NewsType} cat="Updates"/>}
    }
    )
    setSearchNews(cat)
}
setResCount(res.data.NewsList.length)
    }
   
    getData();
}
}catch(err)
{
  console.log(err)
}
}   
    return(
        <div>
             {isTabletOrMobile && <Container fluid={true} style={{paddingRight:"90px",paddingLeft:"90px"}}><Row>
                 <Col sm="8">
                     <CatTop CatName="Search"/>                 
             <Typography component="h4" variant="body1" className="mt-3  mb-3 medium font-weight-bold h6" style={{fontSize:"15px",flexDirection:"Row"}} >
             “{resCount}”<span style={{color:"#0a0a0a6b"}}> result for </span>“{searchval}”<span style={{color:"#0a0a0a6b"}}> by JJN News</span></Typography>
             <Link className="text-decoration-none" onClick={(event)=>searchN(event.target.value)}><SearchSharpIcon className="shadow rounded"style={{position:"absolute",backgroundColor:"#f70d28",border:"1px solid #343a40",color:"aliceblue",height:"34px",width:"40px",padding:"4px",left:"auto",right:"13px",cursor:"pointer"}}/>
                 </Link>
                 <Input className="py-1 my-3" style={{height: "calc(1em + 1rem + 2px)",maxWidth:"95%"
      }}
        type="search"
        name="search"
        id="exampleSearch"
        value={searchval}
        placeholder="Search..."  onChange={(event)=>searchN(event.target.value)}
      />
        {searctNews}
           </Col>
             <Col sm="4">
                 </Col></Row></Container>}
{/*for mobile*/}
            {dis &&  <Container fluid={true} >
                <Row>
                <Col sm="8">
                <CatTop CatName="Search"/>
                <Typography component="h4" variant="body1" className="mt-3  mb-3 medium font-weight-bold h6" style={{fontSize:"15px",flexDirection:"Row"}} >
                “{resCount}”<span style={{color:"#0a0a0a6b"}}> result for </span>“{searchval}”<span style={{color:"#0a0a0a6b"}}> by JJN News</span></Typography>
                <SearchSharpIcon onClick={(event)=>searchN(event.target.value)}className="shadow rounded"style={{position:"absolute",backgroundColor:"#f70d28",border:"1px solid #343a40",color:"aliceblue",height:"34px",width:"40px",padding:"4px",left:"auto",right:"13px"}}/>
                 
                 <Input className="py-1" style={{height: "calc(1em + 1rem + 2px)",maxWidth:"92%"
      }}
        type="search"
        name="search"
        id="exampleSearch"
        placeholder="Search..." onChange={(event)=>searchN(event.target.value)}
      />
              </Col>
             <Col sm="4">
                 </Col>
                </Row>
                </Container>}
        </div>
    )
} 
export default Search;