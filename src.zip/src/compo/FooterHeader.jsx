import React, {useState,useEffect,useRef} from "react"
import {
    Navbar,
    Nav,
    NavItem,
    NavLink
  } from 'reactstrap';
 
  import HomeIcon from '@material-ui/icons/Home';
  import LiveTvIcon from '@material-ui/icons/LiveTv';
  import NotificationsIcon from '@material-ui/icons/Notifications';
  import TvSharpIcon from '@material-ui/icons/TvSharp';
  import SearchSharpIcon from '@material-ui/icons/SearchSharp';
  import axios from 'axios';
  import './footerHeader.module.css';
  //import { makeStyles } from '@material-ui/core/styles';
  import Select from '@material-ui/core/Select';
import Notification from "./Home/Notification";
import { Modal, ModalHeader, ModalBody,Input } from 'reactstrap';

const currDate = new Date().toLocaleDateString();
const FooterHeader=(props)=>{

  const [dropdownOpen, setDropdownOpen] = useState(false);
  const toggl = () => setDropdownOpen(prevState => !prevState);  
   // const [isOpen, setIsOpen] = useState(false);
    const [catName, setCatName]=useState();
 //   const toggle = () => setIsOpen(!isOpen);
    const [liveVideo, setLiveVideo]= useState();
    const [not, setNot]=useState();
    const[search, setSearch]=useState();
    const[searchval, setSearchVal]=useState();
    const[searchResult, setSearchResult]=useState([]);
  // let val=0;
  
    const SearchN=(key)=>
    { 
      setSearchVal(key)
      try{
      if(key !=="")
      {
        async function getData()
        {  const res= await axios.get(`https://panel.jagratjantanews.com/api/Search/Get?SearchText=${key}`) 
        }
        getData()
      }
     
      
    }catch(err)
    {
      console.log(err)
    }
    }
   
    const handleKeypress = (e) => {
    
      //it triggers by pressing the enter key
    if (e.charCodeAt === 13) {
      console.log("deepali");
     // setSearchVal(e);
    }
    else
    {
      console.log(e);
    }
  };

    const absSearch =()=>
    {//val++;
      return setSearch(
        
        <Input className="py-1" style={{height: "calc(1em + .68rem + 2px)",width:"280px"
      }} icon={false}
        type="search"
        name="search"
        id="Search"
        value={searchval}
        placeholder="Search..."  onKeyPress={(event)=>handleKeypress(event.target.value)}
      />
      
      )
    }
    try{
         useEffect(() => {
      
      async function getData()
      {
        const r = await axios.get(`https://panel.jagratjantanews.com/api/LiveVideo/Get`)
        setLiveVideo(r.data.VideoUrl)
          const res = await axios.get(`https://panel.jagratjantanews.com/api/Menu/GetAll`)
        
          let count =0, b=0;
          let a,check;
              const cat = res.data.MenuList.map((cvalue,i)=>
            {    
              if(count<11){
           if(res.data.MenuList[i].SubMenuList.length ===0) 
           { 
          a= <NavItem key={cvalue.Id}>
          <NavLink exact="true" name={cvalue.Url}
            href={`/${cvalue.Url}`}
            className="text-white mx-1 manu " style={{whiteSpace:"nowrap"}}>{cvalue.Name}</NavLink> </NavItem>
           
           }
           else{
           a= <NavItem key={cvalue.Id}>
            <NavLink exact="true" name={cvalue.Url}
              href={`/${cvalue.Url}`}
              className="text-white ml-1 pr-0 manu" style={{whiteSpace:"nowrap",paddingTop:"1px"}}>
                {cvalue.Name} 
               <Select className="text-white"> 
               {cvalue.SubMenuList.map((op, i) =>
                 <NavItem key={i}>  
                 <NavLink exact="true" 
                   href={`/${cvalue.Url}/${op.Url}`} subcat={op.Url} 
                   className="text-dark mx-1 manu " style={{whiteSpace:"nowrap"}}>{op.Name}
                   </NavLink></NavItem>
                    )}
                  
    </Select></NavLink> </NavItem>
    b++;
           }
                  count ++;
              }
              else{
              a=i<11? 
                 <Select className="text-white"> 
                 { res.data.MenuList.map((c,j)=>
                      {
                       return  j>=10?<NavItem key={j}>
                        <NavLink exact="true" name={c.Url}
                          href={`/${c.Url}`}
                          className="text-dark mx-1 manu " style={{whiteSpace:"nowrap"}}>{c.Name}
                          </NavLink> </NavItem>:null
                      }
                   
                      )}
      </Select>
                  
                  :null
                       
            }
          
            return a;
            
           } )
             setCatName(cat)    
             
            if(b!==0)
              {
                check=true;
              }
              else{
                check=false;
              }
              let notify
              const reN= await axios.get(`https://panel.jagratjantanews.com/api/Notification/Get`) 
              if(reN.data.NewsList.length===0)
              {
                return setNot ( <ModalBody >
                "No Updates Yet!!"   
                  </ModalBody>)
              }
              else{
              const cat1 = reN.data.NewsList.map((c,i)=>
              { 
               return  notify= i<=2?
                <ModalBody key={c.i}>
            {c.Title}   
              </ModalBody>
              :null
              })
              setNot(cat1)
            }
      } 
      
      getData();   
    },[]);}catch(err)
    {
      console.log(err)
    }
    function  noty () {
       <Notification/>
     
       // do something here
      }
      const {
        className
      } = props;
    
      const [modal, setModal] = useState(false);
    
      const tog = () => setModal(!modal);
    return(
        <div>       
  <Navbar nav="true" light expand="md" className="py-0 h6 pl-5" style={{fontSize:"15px"}}>    
  
          < Nav className="mr-auto " navbar style={{fontSize:"14px",fontWeight:"bold",height:"30px",overflow:"hidden"}}>
          <NavItem key="100">
          <NavLink href="/"  className="text-white mx-1 py-1" ><HomeIcon/></NavLink>  
        </NavItem>
          {catName}
       {   <NavItem key="101">
          <NavLink href={liveVideo} className="text-white mx-1 py-1" ><LiveTvIcon/></NavLink>
        </NavItem>}
        <NavItem key="102">
                        <NavLink className="text-white manu" style={{whiteSpace:"nowrap",paddingTop:"4px",cursor:"pointer"}} onClick ={noty}>
                        <NotificationsIcon  onClick={tog}/>              
   
        </NavLink> 
        </NavItem>
      <Modal isOpen={modal} toggle={tog} className={className} >
        <ModalHeader toggle={tog}>Notification<span className="text-danger mx-3">(New)</span><span className="float-right">{currDate} </span> </ModalHeader>
       {not}
        
      </Modal>   
        <NavItem key="103">
          <NavLink  href="/Shows" className ="text-white mx-1 py-1" ><TvSharpIcon/></NavLink>
        </NavItem>
        <NavItem key="104">
          <NavLink href="/Search" className ="text-white mx-1 py-1"  style={{cursor:"pointer"}} ><SearchSharpIcon /></NavLink>{/*onClick={absSearch}*/}
        </NavItem>
        {search}
            </ Nav>
           
  </Navbar>
  <style>
    {
      `.MuiSelect-select.MuiSelect-select {
        padding-right: 7px;}
        .MuiSelect-icon {
          color:white;}
          .modal-title {
            width:100%;
          }
        .modal-content
      {
        max-height:255px;
      }}`
    }
  </style>
    </div>
    )
}
export default FooterHeader;