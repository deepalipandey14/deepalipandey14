import React from 'react';
import img2 from '../../images/img2.png'
import SideCard1 from '../Home/SideCard1';
const CatSubContainer2=(props)=>{
    return (<div>
 <SideCard1 src={img2} editorName="cxjkhgjxjcb" date="23/01/2021" heading="सर्दी के मौसम में लोगों को राहत देने निकले जमीयत उलेमा हिन्द के सदस्य"/>
    </div>)
        
}
export default CatSubContainer2;