import React from 'react'
import { Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import Link from '@material-ui/core/Link';
const useStyles = makeStyles((theme) => ({
    Bg: {
        backgroundSize:'cover',
        backgroundPosition:'center',
        position: 'relative',
        backgroundRepeat:'no-repeat'
      },
      text:
      {
        textAlign: 'center',
        position: 'absolute',
        top: '50%',
        left:'50%',
        transform: "translate('-50%', '-50%')",
        color: 'white',
      }
}))
const Comp3=(props)=>
{let s
  if(props.sub==="null")
  {
    s="Story"
  }
  else{
    s=props.sub
  }
    const classes = useStyles();
    return(
      <Link href={`/${props.cat}/${s}/${props.href}`} className="text-decoration-none"><div  className={classes.Bg} style={{backgroundImage: `url(${props.img})`, margin:"8px 0", backgroundRepeat:'no-repeat',minHeight:"120px",position:"relative" }} >
      <Typography className="font-weight-bolder text-white "style={{position:"absolute",left:"10px",right:"10px",bottom:"10px",overflow:"hidden",height:"20px"}}classes={classes.text}>{props.title} </Typography>
      
       </div></Link>
     )
}
export default Comp3;