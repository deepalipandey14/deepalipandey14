

// import Swiper core and required modules
import React, { useRef, useState,useEffect } from "react";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";
import CardList from '../Home/CardList';
  
  // Import Swiper styles
  import "swiper/swiper.min.css";
  import "swiper/components/pagination/pagination.min.css"
  import "./flickity.css";
  // import Swiper core and required modules
  import SwiperCore, {
    Pagination
  } from 'swiper/core';
  import axios from 'axios';
  import { Row, Col } from 'reactstrap';
  // install Swiper modules
  SwiperCore.use([Pagination]);
  export default function Slider(props) {
    const [topTitle, setTopTitle]= useState();
    try{
    useEffect(() => {
      async function getData()
      {
        //const res1 = await axios.get(`https://panel.jagratjantanews.com/api/Menu/GetAll`)
          const res = await axios.get(`https://panel.jagratjantanews.com/api/News/AllNews`)
          const cat = res.data.NewsList.map((cvalue,i)=>
          {
          
         return i<=3 ?<Col md={3}sm={6} xs={6}> 
             <CardList cat="Updates" sub={cvalue.NewsType} title={cvalue.Title} img={cvalue.CoverImage} href={cvalue.Url} /></Col>:null     
            
          })
             setTopTitle(cat); 
             
      }
      getData();
    });}catch(err)
    {
      console.log(err)
    }
    return (
      <>
       <Row className="mt-2"style={{display:"flex",flexDirection:"row",flexWrap: "nowrap",
    overflowX: "scroll"}}>
     
    {topTitle}
 
    </Row>
      </>
  
  )
}