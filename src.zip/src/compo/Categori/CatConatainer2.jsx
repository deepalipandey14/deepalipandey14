import React,{useEffect,useState} from 'react';
import { Row, Col} from 'reactstrap';
//import { useMediaQuery } from 'react-responsive';
//import CatTop from '../Categori/CatTop';
//import CatContainer1 from '../Categori/CatContainer1';
//import Heading from '../Home/Heading';
import Last from '../Home/Last';
import Bg from '../page/BgCompo'
import CardList1 from '../Categori/CardList1';
import Page from '../Page';
import axios from 'axios';
const CatContainer2=(props)=>
{   const [news, setNews]=useState();
   const [reNews, setReNews]=useState();
   const [page, setPage]=useState();
   const [showperpage, setShowPerPage]=useState(11);
   //let s
{/*   const [pagination, setPagination]=useState(
     {
       start:4,
       end:showperpage,
     }
     
   ); */}
   try{
   let c=0
   let start=4,end=11;
   const card=(start,end)=>
   {    async function getData2()
    { 
     
    if(props.subCat===undefined)
    {
      const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.catName}`)
     let len= res1.data.NewsList.length;
      setPage(<Page cat={props.catName}sub={props.subCat} showperpage={showperpage} OnPagination={OnPagination} totle={len}/>)
     
      const cat = res1.data.NewsList.slice(start, end).map((cvalue,i)=>
     { 
   return  <Col xs="6" sm="4">
       
     <CardList1 key={i}  href={cvalue.Url}title={cvalue.ShortDescription} img={cvalue.CoverImage} date={cvalue.CreatedOn} fName={cvalue.CreatedByFirstName}mName={cvalue.CreatedByMiddleName}lName={cvalue.CreatedByLastName} cat={props.catName} sub={props.subCat}/>
       </Col>
      
     })
     setNews(cat);
    }
      else{ 
      const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/GetBySubCategory?url=${props.subCat}`)
      let len= res1.data.NewsList.length;
      setPage(<Page cat={props.catName} sub={props.subCat}  showperpage={showperpage} OnPagination={OnPagination} totle={len}/>)
      
      const cat3 = res1.data.NewsList.slice(start,end).map((cvalue,i)=>
     { 
   return <Col xs="6" sm="4">
       
     <CardList1 key={i}cat={props.catName} sub={props.subCat} href={cvalue.Url}title={cvalue.ShortDescription} img={cvalue.CoverImage} date={cvalue.CreatedOn} fName={cvalue.CreatedByFirstName}mName={cvalue.CreatedByMiddleName}lName={cvalue.CreatedByLastName}/>
       </Col>
     })
     setNews(cat3);
      }
    }
    getData2()
   }
   const OnPagination =(start, end)=>
   {
   //setPagination({start:start,end:end})
   if(c===0)
   { 
    card(4,end);
     c++;
   }
   else{
   
    card(start,end);
   }
  
   }
      useEffect(() => {
      async function getData()
      {let a
        const r = await axios.get(`https://panel.jagratjantanews.com/api/News/AllNews`)
        const cat2 = r.data.NewsList.map((c,i)=>
        {
         if(i===0)
         {
          
         a= <Bg cat={c.Url}  href={c.Url}title={c.Title} img={c.CoverImage} fName={c.CreatedByFirstName}mName= {c.CreatedByMiddleName} lName={c.CreatedByLastName} date={c.CreatedOn}/>
         } 
         else if(i>=1 && i<=2)
         {   
          a=<Last cat={c.Url} src={c.CoverImage}  heading={c.Title} href={c.Url}/>
          
         }
         else{
           a=null
         }
         return a
        });
        setReNews(cat2)
     if(props.subCat===undefined)
        {
          const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.catName}`)
         let len= res1.data.NewsList.length;
         
          setPage(<Page cat={props.catName}sub={props.subCat} showperpage={showperpage} OnPagination={OnPagination} totle={len}/>)
      
          const cat = res1.data.NewsList.slice(start, end).map((cvalue,i)=>
         { 
       return  <Col xs="6" sm="4">
           
         <CardList1 key={i}  href={cvalue.Url}title={cvalue.ShortDescription} img={cvalue.CoverImage} date={cvalue.CreatedOn} fName={cvalue.CreatedByFirstName}mName={cvalue.CreatedByMiddleName}lName={cvalue.CreatedByLastName} cat={props.catName} sub={props.subCat}/>
           </Col>
          
         })
         setNews(cat);
        }
          else{ 
          const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/GetBySubCategory?url=${props.subCat}`)
          let len= res1.data.NewsList.length;
          
          setPage(<Page cat={props.catName} sub={props.subCat}  showperpage={showperpage} OnPagination={OnPagination} totle={len}/>)
          
          const cat3 = res1.data.NewsList.slice(start,end).map((cvalue,i)=>
         { 
       return <Col xs="6" sm="4">
           
         <CardList1 key={i}cat={props.catName} sub={props.subCat} href={cvalue.Url}title={cvalue.ShortDescription} img={cvalue.CoverImage} date={cvalue.CreatedOn} fName={cvalue.CreatedByFirstName}mName={cvalue.CreatedByMiddleName}lName={cvalue.CreatedByLastName}/>
           </Col>
         })
         setNews(cat3);
        }   
      } 
      getData();  
    },[]);
  }catch(err)
  {
    console.log(err)
  }
    return (
        <div>
              <Row>
               {news}
               </Row>
                <Row className="text-center"> {page}</Row>
        </div>
    )
}
export default CatContainer2;