import React,{useEffect,useState} from 'react';
import axios from 'axios';
import Comp3 from './Comp3';
import { Col,Row} from 'reactstrap'
const Comp4=(props)=>
{
    const [title, setTitle]=useState();
    try{
    useEffect(() => {
       async function getData()
       {let a
        if(props.subCat===undefined){
           const res = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.name}`)
           
           const cat = res.data.NewsList.map((c,i)=>
           {
        a= i>=2 && i<=3?
           a=    <Col sm="6" className="mt-1">
           <Comp3 cat={props.name} sub="null" key={i} href={c.Url} title={c.Title} img={c.CoverImage} />
            </Col>:
                    a=null
        return a
           }   
        )
        setTitle(cat)}
        else
        {
            const res = await axios.get(`https://panel.jagratjantanews.com/api/News/GetBySubCategory?url=${props.subCat}`)
           
           const cat = res.data.NewsList.map((c,i)=>
           {
        a= i>=2 && i<=3?
           a=    <Col sm="6" className="mt-1">
           <Comp3 sub={props.subCat} key={i} href={c.Url} title={c.Title} img={c.CoverImage} />
            </Col>:
                    a=null
        return a
           }   
        )
        setTitle(cat) 
        }
    } 
    getData();  
 
  },[]);}catch(err)
  {
    console.log(err)
  }
    return(
        <div>
            <Row>{title}</Row>
        </div>
    )
}
export default Comp4;