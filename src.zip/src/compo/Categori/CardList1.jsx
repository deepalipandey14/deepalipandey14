import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import UpdateIcon from '@material-ui/icons/Update';
import Link from '@material-ui/core/Link';
const useStyles = makeStyles({
    root: {
      marginTop:15,  
    },
  });
  
const CardList1=(props)=>{
  let s;
    const classes = useStyles();  
    if(props.sub===undefined)  
    {
      s="Story"
  
    }
    else{
      s=props.sub
    
    }
    return (
      <Link href={`/${props.cat}/${s}/${props.href}`} className="text-decoration-none" >
<Card className={classes.root} >
      <CardActionArea >
        <CardMedia
          component="img"
          height="140"
          alt="News"
          href={props.href}
          src={props.img} 
        />
        <CardContent>
          <Typography variant="body2"  component="span"className="font-weight-bold">
         <div style={{overflow:"hidden",maxHeight:"55px",minHeight:"55px",color:"#0000008c"}}>{props.title}</div> 
          </Typography>
        </CardContent>
      </CardActionArea>
      <CardActions>
      <Typography variant="body2" component="span" className="small my-2 pb-2 " style={{overflow:"hidden",minHeight:"38px",color:"#0000008c"}}>By
<Typography className="text-danger" component="span"   variant="h6"> {props.fName} {props.mName} {props.lName}</Typography> <Typography style={{color:"#0000008c"}} component="span" className=" small pl-0" variant="span"><UpdateIcon style={{fontSize:"1rem"}}/> {props.date}</Typography></Typography>    
      </CardActions>
    </Card>
    </Link>
    )
}
export default CardList1;