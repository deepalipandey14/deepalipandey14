import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import CardActions from '@material-ui/core/CardActions';
import Button from '@material-ui/core/Button';
import UpdateIcon from '@material-ui/icons/Update';
const useStyles = makeStyles((theme) => ({
    root: {
      display: 'flex',
      margin:"10px 0",
    },
    details: {
      display: 'flex',
      flexDirection: 'column',
      paddingLeft:'15',
    },
    content: {
      flex: '1 0 auto',
      paddingLeft:'20',
    },
   mediaContant:{
       width:'35%',
      
   },
   fonth:
   {
       fontSize:'12',
       fontWeight:'bold'
   }, fontp:
   {
       fontSize:'10'
   }
  }));
  
  export default function ButtonCard(props) {
    const classes = useStyles();
    return (
      <Card className={classes.root}>
            <CardMedia className={classes.mediaContant}
          component="img"
        
          alt="News"
          src={props.src}
        
        />
        <div className={classes.details}>
          <CardContent className={classes.content}>
            <Typography component="h6" variant="h6"className={classes.fonth}>
              {props.heading}
            </Typography>

            <Typography variant="body2"  component="span" className="small my-2 pb-2 text-secondary" >BY
<Typography className="text-danger " component="span"   > {props.editorName}</Typography>
 <Typography component="span" className=" small text-secondary px-3 "style={{color:"#0000008c"}} variant="span"><UpdateIcon style={{fontSize:"1rem"}}/> {props.date}</Typography></Typography>    
 
            <Typography style={{color:"#0000008c"}}variant="span"className={classes.fontp}>
              {props.value}
            </Typography>
          </CardContent>
          <CardActions>
     
        <Button variant="contained" size="small" className="text-white" style={{backgroundColor:"#f70d25"}}>
          Read More
        </Button>
      </CardActions>
        </div>
      
      <style>
          {
              `.MuiCardContent-root {
                padding: 25px;
            } .MuiCardActions-root { padding: 8px 8px 8px 25px;
            }`
          }
      </style>
      </Card>
    );
  }
  