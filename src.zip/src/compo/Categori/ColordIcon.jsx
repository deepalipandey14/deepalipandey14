import InstagramIcon from '@material-ui/icons/Instagram';
import TwitterIcon from '@material-ui/icons/Twitter';
//import LinkedInIcon from '@material-ui/icons/LinkedIn';
import {Row,
    Collapse,
    Navbar,
    Nav,
    NavItem,
    NavLink,
  } from 'reactstrap';
  import FacebookIcon from '@material-ui/icons/Facebook';
  const ColordIcon=(props)=>
  {
      return(
          <div>
              
 <Row className="my-3 py-1">
<Navbar light expand="md"className="py-0 px-1 small">
<Collapse  navbar>
<Nav className="mr-auto " navbar>
<NavItem>
  <NavLink href="https://www.facebook.com/jjnnewsofficial" style={{color:"#4267B2"}} className=" py-1" ><FacebookIcon/></NavLink>
</NavItem>
<NavItem>
  <NavLink href="https://www.instagram.com/jjnnewsofficial" style={{color:"#C13584"}} className=" py-1" ><InstagramIcon/></NavLink>
</NavItem>
{/*
<NavItem>
  <NavLink href="/components/" style={{color:"#0e76a8"}} className=" py-1" ><LinkedInIcon/>
  </NavLink>
</NavItem>*/}
<NavItem>
  <NavLink href="https://twitter.com/jjnnewsofficial"style={{color:"#1DA1F2"}} className=" py-1" ><TwitterIcon/>
  </NavLink>
</NavItem>
</Nav>


</Collapse>
</Navbar>
 </Row>
          </div>
      )
  }
  export default ColordIcon;




