import React,{useEffect,useState} from 'react';
import { Col, Row } from 'reactstrap'
import Comp4 from './Comp4';
import BgCompo from '../page/BgCompo';
import axios from 'axios';
import Comp2 from './Comp2';
const CatContainer1=(props)=>
{
    const [news1, setNews1]=useState();
    try{
    useEffect(() => {
       async function getData()
       {let a
        if(props.subCat===undefined){
      const res = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.name}`)
   
      const cat = res.data.NewsList.map((c,i)=>
           {
            if(i===0){
           a= <BgCompo key={i} cat={props.name} sub="null"href={c.Url} title={c.Title} img={c.CoverImage} fName={c.CreatedByFirstName}mName= {c.CreatedByMiddleName} lName={c.CreatedByLastName} date={c.CreatedOn}/>
           }
          else
          {
           a= null
          }
        return a;
        })
        setNews1(cat)}
        else{
          const res = await axios.get(`https://panel.jagratjantanews.com/api/News/GetBySubCategory?url=${props.subCat}`)
           
          const cat = res.data.NewsList.map((c,i)=>
          {
           if(i===0){
          a= <BgCompo key ={i}cat={props.name} sub={props.subCat} href={c.Url} title={c.Title} img={c.CoverImage} fName={c.CreatedByFirstName}mName= {c.CreatedByMiddleName} lName={c.CreatedByLastName} date={c.CreatedOn}/>
          }
         else
         {
          a= null
         }
       return a;
          
       })
       setNews1(cat)
        }
    } 
    getData();  
    
  },[]);}catch(err)
  {
    console.log(err)
  }
    return(<div>  
        <Row>
            <Col sm="6">
           {news1}
            </Col>
            <Col sm="6">
            <Comp2 name={props.name}subCat={props.subCat}/>
            <Comp4 name={props.name}subCat={props.subCat}/> 
            </Col>
            </Row>
         
    </div>)
}
export default CatContainer1;