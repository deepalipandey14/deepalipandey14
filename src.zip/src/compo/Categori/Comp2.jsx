import React,{useEffect,useState} from 'react';
import { Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import Link from '@material-ui/core/Link';
import axios from 'axios';
const useStyles = makeStyles((theme) => ({
    Bg: {
        backgroundSize:'cover',
        backgroundPosition:'center',
        position: 'relative',
        backgroundRepeat:'no-repeat'
      },
      text:
      {
        textAlign: 'center',
        position: 'absolute',
        top: '50%',
        left:'50%',
        transform: "translate('-50%', '-50%')",
        color: 'white',
      }
}))
const Comp2=(props)=>
{
  const classes = useStyles(); 
  const [news1, setNews1]=useState();
  try{
  useEffect(() => {
     async function getData()
     {let a,s
      if(props.subCat===undefined){
         const res = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.name}`)
        s="Story";
       
         const cat = res.data.NewsList.map((c,i)=>
         {
        if(i===1)
        {
          
         a=  <Link href={`/${props.name}/${s}/${c.Url}`} className="text-decoration-none"><div  className={classes.Bg} style={{backgroundImage: `url(${c.CoverImage})`, margin:"8px 0 0 0", backgroundRepeat:'no-repeat',minHeight:"160px",position:"relative" }} >
    <Typography className="font-weight-bolder text-white "style={{position:"absolute",left:"10px",right:"10px",bottom:"10px",overflow:"hidden",height:"20px"}}classes={classes.text}>{c.Title}</Typography>
    
     </div></Link>
          
        }
        else{
          a=null
        }
        return a 
      })
      setNews1(cat)
    }
    else
    {
      
      const res = await axios.get(`https://panel.jagratjantanews.com/api/News/GetBySubCategory?url=${props.subCat}`)
          s=props.subCat
         const cat = res.data.NewsList.map((c,i)=>
         {
         
        if(i===1) 
        {
         a=  <Link href={`/${props.name}/${s}/${c.Url}`} className="text-decoration-none"><div  className={classes.Bg} style={{backgroundImage: `url(${c.CoverImage})`, margin:"8px 0 0 0", backgroundRepeat:'no-repeat',minHeight:"160px",position:"relative" }} >
    <Typography className="font-weight-bolder text-white "style={{position:"absolute",left:"10px",right:"10px",bottom:"10px",overflow:"hidden",height:"20px"}}classes={classes.text}>{c.Title}</Typography>
    
     </div></Link>
          
        }
        else{
          a=null
        }
        return a 
      })
      setNews1(cat)
    }
  } 
  
  getData();  
},[]); }catch(err)
{
  console.log(err)
}
    return(
      
     <div>
       {news1}
     </div>
     )
     
}
export default Comp2;