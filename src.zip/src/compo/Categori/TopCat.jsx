
import React from 'react';
import {
    Nav,
    NavItem,
    NavLink,
  } from 'reactstrap';
  import { makeStyles } from '@material-ui/core/styles';
  import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
  const useStyles = makeStyles((theme) => ({
    colorclass:
    {
        marginBottom:10
    }}))
const TopCat=(props)=>
{
  
    const classes = useStyles();
    return (<div className={classes.colorclass} >
            <Nav  style={{fontSize:"14px"}} >
        <NavItem>
               <NavLink href="/" className="text-secondary  px-1  py-0" >Home</NavLink>
            </NavItem><ArrowForwardIosIcon style={{fontSize:"0.6rem",height:"1.5rem"}}/><NavItem>
              <NavLink href={`/Category/${props.CatName}`} className=" py-0" style={{color:"#f70d28"}} >{props.CatName}</NavLink>
            </NavItem><ArrowForwardIosIcon style={{fontSize:"0.6rem",height:"1.5rem"}}/><NavItem>
              <NavLink href={`/Category/${props.CatName}`} className=" py-0" style={{color:"#f70d28"}} >{props.subCat}</NavLink>
            </NavItem>
            </Nav>
        
    </div>)
}
export default TopCat;