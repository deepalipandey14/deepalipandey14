import React,{useEffect,useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import UpdateIcon from '@material-ui/icons/Update';
import Link from '@material-ui/core/Link';
import axios from 'axios';
const useStyles = makeStyles({
    root: {
      marginTop:15,  
    },
  });
  
const SCardList=(props)=>{
    const classes = useStyles();    

    return (
      <Link href="/ShowPage" className="text-decoration-none" >
<Card className={classes.root} >
      <CardActionArea >
        <CardMedia
          component="img"
          height="140"
          alt="News"
          href={props.href}
          src={props.img}
          />    
        <CardContent >
          <Typography variant="body2"  component="span"className="font-weight-bold"style={{color:"#0000008c",overflow:"hidden",height:"39px",marginTop:"22px"}}>
          {props.title}
          </Typography>
        </CardContent>
      </CardActionArea>
      <CardActions>
      <Typography variant="body2" component="span" className="small my-2 pb-2 " style={{color:"#0000008c"}}>
<Typography className="text-danger" component="span"   variant="h6"> {props.time}
</Typography> <Typography component="span" className=" small pl-0" variant="h6" style={{color:"#0000008c"}}>
    <UpdateIcon style={{fontSize:"1rem"}}/> {props.date}</Typography></Typography>    
      </CardActions>    
    </Card>
    </Link>
    )
}
export default SCardList;