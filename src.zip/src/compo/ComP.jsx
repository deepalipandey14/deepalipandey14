import { Typography } from '@material-ui/core'
import React from 'react'
const ComP=(props)=>
{
    return(
        <div className="my-3">
            <Typography  variant="h6" style={{fontWeight:"400", colo:"#333"}}>
                {props.value}
            </Typography>
        </div>
    )
}
export default ComP;