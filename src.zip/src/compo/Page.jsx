import React,{useEffect,useState} from 'react';
import { Pagination, PaginationItem, PaginationLink } from 'reactstrap';
const Page = (props) => {

  //const [page, setPage]=useState();
  
  const [numberOfButton, setnumberOfButton]=useState(Math.ceil(props.totle/props.showperpage));
  const [counter, setCounter]=useState(1);
  const onButtonClick =(type)=>
  { 
if(type==="prev")
{
if(counter===1)
{
  setCounter(1)
}
else
{
  setCounter(counter - 1)
}
}
else if( type==="next")
{
  if(numberOfButton===counter)
  {
    setCounter(counter)
  }
  else{
    setCounter(counter + 1)
  }
}

  }
  
  useEffect(() => {  
    const value = props.showperpage *counter; 
    props.OnPagination (value-props.showperpage,value)

},[counter])
  return (<div className="mt-4 text-center">
    <Pagination>
      <PaginationItem  >
        <PaginationLink  first href="#" onClick ={()=> onButtonClick ('prev') }/>
      </PaginationItem>
     
      {
            new Array(numberOfButton).fill("").map((e,i)=>(
              <PaginationItem key={i} className={`${i+1===counter? "active": null} `}>
              <PaginationLink href="#"  onClick={()=>setCounter(i+1)}>
               {i + 1}
              </PaginationLink>
            </PaginationItem>
            ))
          }
      <PaginationItem>
        <PaginationLink last href="#" onClick ={()=> onButtonClick ('next') } />
      </PaginationItem>
    </Pagination>
    <style>
      {
        `
        .page-item a
        {
          color:black;
        }.page-item.active .page-link  {
          border-color: #f70d28;
          background: #f70d28;
          
          
        }`
      }
    </style>
    </div> 
  );
}

export default Page;