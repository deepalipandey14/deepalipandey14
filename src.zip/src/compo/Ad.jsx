import React from 'react'
import Image from 'react-bootstrap/Image';
const Ad=(props)=>
{
    return(<div className="text-center adButtton">
   
        <Image src={props.ad} className="m-3" style={{maxWidth:"90%"}}/>
    </div>)
}
export default Ad;