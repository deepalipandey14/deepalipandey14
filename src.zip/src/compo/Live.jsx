import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import { Link } from '@material-ui/core';
const useStyles = makeStyles({
    root: {
      marginTop:10,
    },
  });
    
const Live=(props)=>
{
    const classes = useStyles();  
    return (
      <Link href={`/Live/${props.type}/${props.href}`}  className="text-decoration-none">
        <Card className={classes.root} >
      <CardActionArea >
        <CardMedia
          component="img"
          height="200"
          alt="News"
          src={props.src} 
        />
        <CardContent ><Typography variant="body2" style={{color:"#0000008c"}} component="span" className="small mt-1 pt-1" >by
       <Typography className="text-danger " component="span"   variant="h6"> {props.fName} {props.mName} {props.lName}</Typography> <Typography component="span"style={{color:"#0000008c"}} className="float-sm-right small" variant="h6"> {props.date}</Typography></Typography>    
       <Typography variant="body1"style={{maxHeight:"55px",lineHeight:"28px",overflow:"hidden",color:"#0000008c"}} component="span"className="pt-1 font-weight-bold">
          {props.title}
          </Typography>
        </CardContent>
      </CardActionArea>
    </Card>
    </Link>
    )
}
export default Live;