import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import Link from '@material-ui/core/Link';
import React from "react"

const useStyles = makeStyles((theme) => ({
    root: {
      display: 'flex',
      margin:"50px 0",
    },
    details: {
      display: 'flex',
      flexDirection: 'column',
    },
    content: {
      flex: '1 0 auto',
    },
   mediaContant:{
       maxWidth:'35%',
       flex: 'auto',
   },
   fonth:
   {
       fontWeight:'bold',
       height:"59px",
       overflow:"hidden",
   }, 
  }));
  export default function Sea(props) {
    const classes = useStyles();
    return (
       
        <Link href={`/${props.cat}/${props.sub}/${props.href}`} className="text-decoration-none">
              <Card className={classes.root}>
                    <CardMedia className={classes.mediaContant}
                  component="img"
                  height="130"
                  alt="News"
                  src={props.src}
                
                />
                <div className={classes.details}>
                  <CardContent className={classes.content}>
                    <Typography component="h6" variant="body1"className={classes.fonth}style={{fontSize:"0.885rem",color:"#000000b3"}}>
                      {props.heading}
                    </Typography>
                    
                  </CardContent>
                  
                </div>
              
              </Card>
              </Link>
              
            );
          }
          