import React,{useState,useEffect} from 'react'
import SideCard from './Home/SideCard';
import Heading from './Home/Heading';
import SideMedia from './Home/SideMedia';
import Section6 from './Home/Section6';
import live from '../images/live.png';
import axios from 'axios';
const CommSideSection=(props)=>
{
    const [Update, setUpdate]=useState();
    try{
    useEffect(() => {
        async function getData()
        {
        
            
            const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/AllNews`)
           
            const cat = res1.data.NewsList.map((c,i)=>
            {
             return i<2?  <SideMedia href={c.Url} heading={c.Title} value={c.ShortDescription} />: null
            });
            setUpdate(cat)
        }
             
        getData();
      
        
    });}catch(err)
    {
      console.log(err)
    }
    return(
        <div>
                 <SideCard src={live}/>
               <Heading value1="Recent" value2="News"/>
               {Update}
           <Heading value1="Spo" value2="rts"/>
           <Section6 name="sports" fv="0" lv="3"/>
        
              
        </div>
    )
}
export default CommSideSection;