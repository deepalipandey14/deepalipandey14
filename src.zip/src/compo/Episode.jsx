import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
//import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
//import Link from '@material-ui/core/Link';
//import Media from './Home/Media';
import {Row,Col,Container} from 'reactstrap';

const useStyles = makeStyles((theme) => ({
    root: {
     
      margin:"10px 0",
    },
    details: {
      display: 'flex',
      flexDirection: 'column',
    },
    content: {
      flex: '1 0 auto',
    },
   mediaContant:{
       maxWidth:'35%',
       flex: 'auto',
   },
   fonth:
   {
       fontWeight:'bold',
       height:"50px",
       overflow:"hidden",
   }, 
  }));
  export default function Episode(props) {
    const classes = useStyles();
  
    return (
   <>
      <Card className={classes.root}>
    <Row>
    <Col sm={4} xs={4}>
    <div className="embed-responsive embed-responsive-16by9 " style={{height:"100%"}}>
  <iframe className="embed-responsive-item"src={props.src}allowfullscreen></iframe>
</div></Col>
        <Col sm={8} xs={8}>  <div className={classes.details}>
          <CardContent className={classes.content}>
            <Typography component="h6" variant="body1"className={classes.fonth}style={{fontSize:"0.885rem",color:"#000000b3"}}>
             Ep. {props.Id} {props.heading}
            </Typography>
            <Typography component="h3" variant="body2"className={classes.fonth}style={{fontSize:"0.885rem",color:"#000000b3"}}>
              {props.des}
            </Typography>
            <Typography component="span" className="small mx-1 "style={{color:"#0000008c"}} variant="h6">
                     {props.date} {props.time}</Typography>
          </CardContent>
         
          
        </div>
        </Col>
          </Row>
      </Card>
    
     </>
    );
  }
  