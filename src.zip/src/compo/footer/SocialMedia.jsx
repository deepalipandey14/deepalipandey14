import InstagramIcon from '@material-ui/icons/Instagram';
import TwitterIcon from '@material-ui/icons/Twitter';
//import LinkedInIcon from '@material-ui/icons/LinkedIn';
import { Typography } from '@material-ui/core';
import {Row,
    Collapse,
    Navbar,
    Nav,
    NavItem,
    NavLink
  } from 'reactstrap';
  import FacebookIcon from '@material-ui/icons/Facebook';
  const SocialMedia=()=>
  {
      return(
          <div>
              
 <Row className="my-2 mx-1">
 <Typography component="h4"  className="pt-1">Follow us
</Typography>

<Navbar light expand="md"className="py-0 px-1 small"  >
<Collapse  navbar>
<Nav className="mr-auto " navbar>
<NavItem>
  <NavLink href="https://www.facebook.com/jjnnewsofficial" className="text-white py-1" ><FacebookIcon/></NavLink>
</NavItem>
<NavItem>
  <NavLink href="https://www.instagram.com/jjnnewsofficial" className="text-white py-1" ><InstagramIcon/></NavLink>
</NavItem>
{/*
<NavItem>
  <NavLink  className="text-white py-1" ><LinkedInIcon/>
  </NavLink>
</NavItem>*/}
<NavItem>
  <NavLink href="https://twitter.com/jjnnewsofficial"className="text-white py-1" ><TwitterIcon/>
  </NavLink>
</NavItem>
</Nav>


</Collapse>
</Navbar>
 </Row>
          </div>
      )
  }
  export default SocialMedia;




