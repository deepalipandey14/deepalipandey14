import {
    Nav,
    NavItem,
    NavLink
  } from 'reactstrap';
const ShowFooter=()=>
{
    return(
        <div>
          
          <Nav className="mr-auto " style={{flexDirection:"row"}} navbar>
            <NavItem>
              <NavLink href="/components/" className="text-white py-1 px-1" >About </NavLink>
            </NavItem>
            <NavItem>
              <NavLink href="/components/" className="text-white py-1 px-1" >Contact </NavLink>
            </NavItem>
            <NavItem>
              <NavLink href="/components/" className="text-white py-1 px-1" >Politics</NavLink>
            </NavItem>
           
            <NavItem>
              <NavLink href="/components/" className="text-white py-1 px-1" >Terms of use </NavLink>
            </NavItem>
          </Nav>
      
     
         
        </div>
    )
}
export default ShowFooter;