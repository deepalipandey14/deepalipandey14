import React from 'react';
import JJNLogo from '../../images/mobileLogo.png';
const Mob=()=>{
  return (
   
  <a href="/"style={{paddingTop:"11px"}}><img src={JJNLogo} alt="logo"/></a>
      
  );
}
export default Mob;