import React, {useState,useEffect} from "react"
import {Row, Col} from 'reactstrap';
import axios from 'axios';
//import { FacebookButton, FacebookCount } from "react-social";
//import img2 from '../../images/img2.png'
const Footeropt=(props)=>{
  const [menuList, setMenuList]=useState();
  const [menuList1, setMenuList1]=useState();
  try{
  useEffect(() => {
  
    async function getData()
    {
        const res = await axios.get(`https://panel.jagratjantanews.com/api/Menu/GetAll`)
        const cat = res.data.MenuList.map((c,i)=>
        {
         if(i>=0 &&i<=4) 
         {
         return <Col key={c.Id} className="border-right "style={{borderColor:" #969090"}}>
         <a nav="true"  href={`/${c.Url}`} style={{textDecoration:"none",color:"white"}}>{c.Name}</a>
       </Col>}
        })
        setMenuList(cat)
        const ca= res.data.MenuList.map((c,i)=>
        {
         if(i>=5 && i<10)
         { 
         return <Col key={c.Id} className="border-right "style={{borderColor:" #969090"}}>
         <a nav="true" href={`/${c.Url}`} style={{textDecoration:"none",color:"white"}}>{c.Name}</a>
       </Col>}
        })
        setMenuList1(ca)
    }
    getData();
  }
  )}catch(err)
  {
    console.log(err)
  }
 //let url = "https://theprint.in/india/meth-human-hair-from-tirupati-ak-47s-mizoram-myanmar-border-remains-smuggling-hotspot/";
  return (
      <div > 
        <Row className="mt-3"style={{fontSize:"14px"}}>
          {menuList}
                  
              </Row >
              <Row className="mb-3 " style={{fontSize:"14px"}}>
                {menuList1}    
              </Row>
 {  /*           <ShareBtn 
  url={url}
  text={text}
  className='ib'
  displayText='Share'
 />
   <FacebookButton url={url} appId="3871301096289998">
        <FacebookCount url={url} title="fjbkkjhkjkkkkkkkkkkkk" image={img2}/>
        {"Share "}
 </FacebookButton>*/}
    </div>
  );
}

export default Footeropt;