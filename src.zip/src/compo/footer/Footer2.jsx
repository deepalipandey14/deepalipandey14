
import {
    Nav,
    NavItem,
    NavLink
  } from 'reactstrap';

const Footer2=()=>
{
    return(
        <div>
          <Nav className="mr-auto " navbar>
            <NavItem>
              <NavLink key={1}href="/components/" className="text-white py-1" >About the JJN </NavLink>
            </NavItem>
           {/* <NavItem>
              <NavLink href="/components/" className="text-white py-1" >Contact </NavLink>
            </NavItem>
           
            <NavItem>
              <NavLink href="/components/" className="text-white py-1" >Terms of use</NavLink>
            </NavItem>*/}
            <NavItem>
              <NavLink key={2} href="/components/" className="text-white py-1" >Privecy Politics</NavLink>
            </NavItem>
            <NavItem>
              <NavLink key={3} href="/components/" className="text-white py-1" >Contact the JJN </NavLink>
            </NavItem>
           
          {/*  <NavItem>
              <NavLink href="/components/" className="text-white py-1" >Advertise with us</NavLink>
            </NavItem>
            <NavItem>
              <NavLink href="/components/" className="text-white py-1" >Accessable help</NavLink>
          </NavItem>*/}
          </Nav>
   
     
           
        </div>
    )
}
export default Footer2;