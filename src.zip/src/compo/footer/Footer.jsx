import React from 'react';
import { Container, Row, Navbar } from 'reactstrap';
  import { Typography } from '@material-ui/core';
  import  Footeropt from './Footeropt';
  import  Footer2 from './Footer2';
  //import  ShowFooter from './ShowFooter';
  import { useMediaQuery } from 'react-responsive';
  import SocialMedia from './SocialMedia';
import MobileFooter from './MobileFooter';
const Footer=(props)=>
{
  const disFooter = useMediaQuery({ query: '(max-width: 1300px)' })
  const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
    return(
       <div className="main-footer">
         {isTabletOrMobile &&
        <Container className=" px-5 py-2 text-white"  style={{background:"#2b2929"}}fluid={true}>
        
            <Typography component="h1"style={{fontSize:"1.3em"}}>Explore the JJN</Typography>
            <Footeropt/>
          
              <Row className="my-2 mx-1">
              <SocialMedia/></Row>
            
            <Row className="border-top">
              
            <Navbar light expand="md"style={{fontSize:"14px"}}>
            <Footer2/></Navbar>
            </Row>
            <Row  className="mt-1">
           <Typography className="pl-4" component="span" style={{fontSize:"14px",fontWeight:"700"}}>Copyright © 2021 JJN. </Typography>  The JJN is not responsible for the content of external sites. 
            </Row>
        </Container>}
       
      {disFooter &&
        <Container className="" style={{backgroundImage:"linear-gradient(#da4242, #8e0000)"}}fluid={true}>
        <MobileFooter/>
       
           { /*<Typography component="h1"style={{fontSize:"1.3em"}}>Explore the JJN</Typography>
            <Footeropt/>
            <Row className="border-top ">
              
            <Navbar light expand="md"style={{fontSize:"14px"}}>
            <ShowFooter/></Navbar>
            </Row>
            <Row sm={{size: 'auto', offset: 1}} className="mt-0">
            <Typography  className="pl-4" component="span" style={{fontSize:"12"}}>Copyright © 2021 JJN.</Typography>
      </Row>*/}
      </Container>}
       </div>



    )

}
export default Footer;

