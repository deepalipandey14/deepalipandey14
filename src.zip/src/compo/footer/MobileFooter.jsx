import React, {useState,useEffect} from "react"
import { makeStyles } from '@material-ui/core/styles';
import BottomNavigation from '@material-ui/core/BottomNavigation';
import BottomNavigationAction from '@material-ui/core/BottomNavigationAction';
import LiveTvIcon from '@material-ui/icons/LiveTv';
import NotificationsIcon from '@material-ui/icons/Notifications';
import TvSharpIcon from '@material-ui/icons/TvSharp';
import SettingsIcon from '@material-ui/icons/Settings';
import Mob from './Mob'
import { Modal, ModalHeader, ModalBody } from 'reactstrap';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  NavbarText
} from 'reactstrap';
import axios from 'axios';
import Notification from '../Home/Notification';
const useStyles = makeStyles({
  root: {
    backgroundImage:"linear-gradient(#da4242, #8e0000)",
    bottom: "0",
    left: "0",
    position:"fixed",
    width: "100%",
  },
});
const currDate = new Date().toLocaleDateString();
const MobileFooter=(props)=> {
    const [liveVideo, setLiveVideo]=useState();
    const [notificationList, setNotificationList]=useState();
    try{
    useEffect(() => {
      
        async function getData()
        {
    const r = await axios.get(`https://panel.jagratjantanews.com/api/LiveVideo/Get`)
    setLiveVideo(r.data.VideoUrl)
    let notify
    const reN= await axios.get(`https://panel.jagratjantanews.com/api/Notification/Get`) 
    if(reN.data.NewsList.length===0)
    {
      return   setNotificationList(<ModalBody >
      "No Updates Yet !!"   
        </ModalBody>)
    }
    else{
    const cat1 = reN.data.NewsList.map((c,i)=>
    { 
     return  notify= i<=2?
      <ModalBody key={c.i}>
  {c.Title}   
    </ModalBody>
    :null
    })
    setNotificationList(cat1)}
    
        }
       
        getData();
    })}catch(err)
    {
      console.log(err)
    }
  const classes = useStyles();
  const [value, setValue] = React.useState('');

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
 
    const {
        className
      } = props;
    
    const [modal, setModal] = useState(false);
    
    const [modal1, setModal1] = useState(false);
    
    const tog = () =>
    {   
        setModal(!modal);
    }
    const togg = () =>
    {   
        setModal1(!modal1);
    }
    
        function  setting () {
        
   
          }
        const color=()=>
        {
            
        }
  return (
      <>
    <BottomNavigation value={value} onChange={handleChange} className={classes.root}>
          <Modal isOpen={modal} toggle={tog} className={className}  style={{marginTop:"100px"}}>
        <ModalHeader toggle={tog}>Notification<span className="text-danger mx-3">(New)</span><span className="float-right">{currDate} </span> </ModalHeader>
       {notificationList}
        
      </Modal> 
   
           <Modal isOpen={modal1} toggle={togg} className="clsName"  style={{marginTop:"100px",float:"right"}}>
      
        <Navbar>
          <Nav navbar>
        <NavItem>
              <NavLink href="/SignUp/" className="text-dark"style={{display:"inline"}} >Sign Up</NavLink>
            </NavItem>
                
              
                <NavItem>
              <NavLink href="/SignUp/" className="text-dark"style={{display:"inline"}} >Your Account</NavLink>
            </NavItem>
               
                <div divider />
                
                <NavItem>
              <NavLink href="/Login" className="text-dark"style={{display:"inline"}} >Log Out</NavLink>
            </NavItem>
            </Nav>
            </Navbar>
      </Modal> 
      <BottomNavigationAction  className="text-white" label="LiveTV"value="LiveTv" href={liveVideo}onmouseover={color} icon={<LiveTvIcon />} />
      <BottomNavigationAction className="text-white" label="Notification" value="Notification"   icon={<NotificationsIcon onClick={tog}  />} />
      <BottomNavigationAction className="text-white" label="JJN" value="JJN"href="/" icon={<Mob />}/>
      <BottomNavigationAction className="text-white"label="Shows" value="Shows" href="/Shows" icon={<TvSharpIcon />} />
      <BottomNavigationAction className="text-white"label="Setting" value="setting"  icon={<SettingsIcon onClick={togg}/>} >
     
        </BottomNavigationAction>

    </BottomNavigation>
   
    <style>
      {
        `
        .modal-title {
          width:100%;
        }
      .clsName .modal-content {
          width: fit-content;
        }
    `  }
    </style>
</>
  );
}
export default MobileFooter;