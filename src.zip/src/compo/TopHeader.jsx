import {useState} from "react"

import {
    Collapse,
    Navbar,
    NavbarToggler,
    Nav,
    NavItem,
    NavLink,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    NavbarText
  } from 'reactstrap';
  import PersonIcon from '@material-ui/icons/Person';
  
function TopHeader(){
    const [isOpen, setIsOpen] = useState(false);

    const toggle = () => setIsOpen(!isOpen);
    return(
        <div>
      <Navbar light expand="md"className="py-0 px-5 small">
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
          <Nav className="mr-auto " navbar >
            <NavItem>
              <NavLink key={1}href="/About/" className="text-white py-1" >About</NavLink>
            </NavItem>
            <NavItem>
              <NavLink key={2} href="/contact/" className="text-white py-1" >Contact</NavLink>
            </NavItem>
            <NavItem>
              <NavLink key={3}href="/Policy/" className="text-white py-1" >Privacy Policy</NavLink>
            </NavItem>
          </Nav>
          <UncontrolledDropdown inNavbar>
              <DropdownToggle nav  className="text-white py-0" >
              <PersonIcon/> SIGN IN
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem className="px-0">
                <NavItem>
              <NavLink href="/SignUp/" className="text-dark"style={{display:"inline"}} >Sign Up</NavLink>
            </NavItem>
                </DropdownItem >
                <DropdownItem className="px-0">
                <NavItem>
              <NavLink href="/SignUp/" className="text-dark"style={{display:"inline"}} >Your Account</NavLink>
            </NavItem>
                </DropdownItem>
                <DropdownItem divider />
                <DropdownItem className="px-0">
                <NavItem>
              <NavLink href="/Login" className="text-dark"style={{display:"inline"}} >Log Out</NavLink>
            </NavItem>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          <NavbarText className="text-white py-1"></NavbarText>
        </Collapse>
      </Navbar>
    </div>
    )
}
export default TopHeader;