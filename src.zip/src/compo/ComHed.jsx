import { Typography } from '@material-ui/core'
import React from 'react'
const ComHed=(props)=>
{
    return(
        <div>
            <Typography className="my-2" component="h6" variant="body1" style={{fontWeight:"700",fontSize:"16px", color:"#333"}}>
                {props.value}
            </Typography>
        </div>
    )
}
export default ComHed;