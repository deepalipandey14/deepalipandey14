import React, {useState,useEffect} from "react"
import clsx from 'clsx';
import axios from 'axios';
import Select from '@material-ui/core/Select';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import CssBaseline from '@material-ui/core/CssBaseline';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import Logo from './Logo';
import {
    NavItem,
    NavLink,
   Input
  } from 'reactstrap';
const drawerWidth = 192;
const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  appBar: {
    transition: theme.transitions.create(['margin', 'width'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: drawerWidth,
    transition: theme.transitions.create(['margin', 'width'], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
  },
  drawerPaper: {
    width: drawerWidth,
  },
  drawerHeader: {
    display: 'flex',
    alignItems: 'center',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
    justifyContent: 'flex-end',
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    marginLeft: -drawerWidth,
  },
  contentShift: {
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
    marginLeft: 0,
  },
}));
//const currDate = new Date().toLocaleDateString();
export default function PersistentDrawerLeft(props) {
  //const [not, setNot]=useState();
  const classes = useStyles();
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  //const [liveVideo, setLiveVideo]= useState();
  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };
  const [catName, setCatName]=useState();
  try{
  useEffect(() => {
    async function getData()
    {
        const res = await axios.get(`https://panel.jagratjantanews.com/api/Menu/GetAll`)
        let a
            const cat = res.data.MenuList.map((cvalue,i)=>
          {    
         
         if(res.data.MenuList[i].SubMenuList.length ===0) 
         {
        a= <NavItem key={cvalue.Id}style={{listStyleType:"none"}}>
        <NavLink  exact name={cvalue.Url}
          href={`/${cvalue.Url}`}
          className="text-dark" >{cvalue.Name}</NavLink> </NavItem>
         
         }
         else{
         a= <NavItem key={cvalue.Id}style={{listStyleType:"none"}}>
          <NavLink  exact name={cvalue.Url}
            href={`/${cvalue.Url}`}
            className="text-dark " >
              {cvalue.Name} 
             <Select className="text-dark" > 
             {cvalue.SubMenuList.map((op, i) =>
               <NavItem key={i}>  
               <NavLink  exact 
                 href={`/${cvalue.Url}/${op.Url}`}
                 className="text-dark ">{op.Name}
                 </NavLink> </NavItem>
                  )}
  </Select></NavLink> </NavItem>
         }
          return a;
          
         } )
           setCatName(cat)    
    } 
    getData();   
  },[]); }catch(err)
  {
    console.log(err)
  }
  return ( 
    <div className={classes.root} >
      
      <CssBaseline />
      <AppBar 
        className={clsx(classes.appBar, {
          [classes.appBarShift]: open,
        })}style={{backgroundImage:"linear-gradient(#da4242, #8e0000)",position:"fixed"}}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            className={clsx(classes.menuButton, open && classes.hide)}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap>
            <Logo/>
          </Typography>
        </Toolbar>
      </AppBar>
      <Drawer
        className={classes.drawer}
        variant="persistent"
        anchor="left"
        open={open}
        classes={   {
          paper: classes.drawerPaper,
        }} 
      >
        <div className={classes.drawerHeader}> 
  
        
        <Input
          type="search"
          name="search"
          id="exampleSearch"
          placeholder="search..."
        />
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === 'ltr' ? <ChevronLeftIcon /> : <ChevronRightIcon />}
          </IconButton>
        </div>
        <Divider />
        
          <NavItem style={{listStyleType:"none"}}>
              <NavLink href="/" className="text-dark">Home</NavLink>
            </NavItem>
        
        <NavItem style={{listStyleType:"none"}}>
              <NavLink href="/About/" className="text-dark" >About</NavLink>
            </NavItem> <NavItem style={{listStyleType:"none"}}>
              <NavLink href="/contact/" className="text-dark" >Contact</NavLink>
            </NavItem> <NavItem style={{listStyleType:"none"}}>
              <NavLink href="/Policy/" className="text-dark" >Privacy Policy</NavLink>
            </NavItem> <NavItem style={{listStyleType:"none"}}>
            <NavLink href="/" className="text-dark" >Bookmark</NavLink>
            </NavItem> <NavItem style={{listStyleType:"none"}}>
            <Divider />
              <NavLink href="/SignUp/" className="text-dark" >LogIn/SignUp</NavLink>
            </NavItem>
      </Drawer>
      <main>
        <div className={classes.drawerHeader} />
      </main>
      <style>
          {
              `.makeStyles-drawerPaper-7 {
                width: 200px;}
                .MuiSelect-select.MuiSelect-select {
                  padding-right: 10px;
              }
              .MuiAppBar-positionFixed {
               
                position: absolute;
              }
               
            }`
          }
      </style>
    </div>
  );
}






