import React, {useState,useEffect} from "react"
import {
    Navbar,
    Nav,
    NavItem,
    NavLink
  } from 'reactstrap';
  
  import HomeIcon from '@material-ui/icons/Home';
   import axios from 'axios';
  import './footerHeader.module.css';
  //import { makeStyles } from '@material-ui/core/styles';
  import Select from '@material-ui/core/Select';
import Notification from "./Home/Notification";
import { Modal, ModalHeader, ModalBody,Input } from 'reactstrap';

const currDate = new Date().toLocaleDateString();
const SliderMenu=(props)=>{
  const [change, sstChange]=useState(
    {
      activeObject:null,
      objets:[{id:1},{id:2},{id:3},{id:4},{id:5}]
    }
  );
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const toggl = () => setDropdownOpen(prevState => !prevState);  
   // const [isOpen, setIsOpen] = useState(false);
    const [catName, setCatName]=useState();
 //   const toggle = () => setIsOpen(!isOpen);
    const [liveVideo, setLiveVideo]= useState();
    const [not, setNot]=useState();
    const[search, setSearch]=useState();
    const[searchval, setSearchVal]=useState();
  // let val=0;
    const SearchN=(key)=>
    {
      setSearchVal(key)
      
      async function getData()
      {  const res= await axios.get(`https://panel.jagratjantanews.com/api/Search/Get?SearchText=${key}`) 
      }
      getData()
    }
    const absSearch =()=>
    {//val++;
      return setSearch(
        
        <Input className="py-1" style={{height: "calc(1em + .68rem + 2px)",width:"280px"
      }} icon={false}
        type="search"
        name="search"
        id="Search"
        value={searchval}
        placeholder="Search..." onClick={(event)=>SearchN(event.target.value)}
      />
      )
    }
    try{
         useEffect(() => {
      
      async function getData()
      {
        const r = await axios.get(`https://panel.jagratjantanews.com/api/LiveVideo/Get`)
        setLiveVideo(r.data.VideoUrl)
          const res = await axios.get(`https://panel.jagratjantanews.com/api/Menu/GetAll`)
        
          let count =0, b=0;
          let a,check;
              const cat = res.data.MenuList.map((cvalue,i)=>
            {    
              if(count<11){
           if(res.data.MenuList[i].SubMenuList.length ===0) 
           { 
          a= <NavItem key={cvalue.Id}>
          <NavLink exact="true" name={cvalue.Url}
            href={`/${cvalue.Url}`}
            className="p-2 mx-2 manu" style={{whiteSpace:"nowrap",color:"#000000bf"}}>{cvalue.Name}</NavLink> </NavItem>
           
           }
           else{
             a=  <div className="px-3">
            <NavItem key={cvalue.Id}>
            <NavLink exact="true" name={cvalue.Url}
              href={`/${cvalue.Url}`}
              className=" ml-1 p-0  manu" style={{whiteSpace:"nowrap",paddingTop:"1px",color:"#000000bf"}}>
                {cvalue.Name} 
               <Select > 
               {cvalue.SubMenuList.map((op, i) =>
                 <NavItem key={i}>  
                 <NavLink exact="true" 
                   href={`/${cvalue.Url}/${op.Url}`} subcat={op.Url} 
                   className="text-dark mx-1 manu " style={{whiteSpace:"nowrap",color:"#000000bf"}}>{op.Name}
                   </NavLink></NavItem>
                    )}
                  
    </Select></NavLink> </NavItem></div>
    b++;
           }
                  count ++;
              }
              else{
              a=i<11? 
                 <Select className="px-0"> 
                 { res.data.MenuList.map((c,j)=>
                      {
                       return  j>=10?<NavItem key={j}>
                        <NavLink exact="true" name={c.Url}
                          href={`/${c.Url}`}
                          className="text-dark mx-2 p-2 manu " style={{whiteSpace:"nowrap",color:"#000000bf"}}>{c.Name}
                          </NavLink> </NavItem>:null
                      }
                   
                      )}
      </Select>
                  
                  :null
                       
            }
          
            return a;
            
           } )
             setCatName(cat)    
             
            if(b!==0)
              {
                check=true;
              }
              else{
                check=false;
              }
              let notify
              const reN= await axios.get(`https://panel.jagratjantanews.com/api/Notification/Get`) 
              if(reN.data.NewsList.length===0)
              {
                return setNot ( <ModalBody >
                "No Updates Yet!!"   
                  </ModalBody>)
              }
              else{
              const cat1 = reN.data.NewsList.map((c,i)=>
              { 
               return  notify= i<=2?
                <ModalBody key={c.i}>
            {c.Title}   
              </ModalBody>
              :null
              })
              setNot(cat1)
            }
      } 
      
      getData();   
    },[]);}catch(err)
    {
      console.log(err)
    }
    function  noty () {
       <Notification/>
     
       // do something here
      }
      const {
        className
      } = props;
    
      const [modal, setModal] = useState(false);
    
      const tog = () => setModal(!modal);
    return(
        <div>       
  <Navbar nav="true" light expand="md" className="p-0 h6 " style={{fontSize:"15px"}}>    
  
          < Nav className="mr-auto " navbar style={{fontSize:"15px",fontWeight:"500",height:"38px",overflow:"hidden",width: "100%",display: "flex",flexWrap: "wrap",overflowX: "scroll"}}>
          <NavItem className="" key="100">
          <NavLink href="/"  className=" mx-2 py-1 abcColor"  ><HomeIcon/></NavLink>  
    </NavItem>
          {catName}
       { /*  <NavItem key="101">
          <NavLink href={liveVideo} className=" mx-2 py-1" ><LiveTvIcon/></NavLink>
        </NavItem>
  <NavItem key="102">
                        <NavLink className="mx-2 py-1 manu" style={{whiteSpace:"nowrap",paddingTop:"4px",cursor:"pointer"}} onClick ={noty}>
                        <NotificationsIcon  onClick={tog}/>              
   
        </NavLink> 
    </NavItem>*/}
      <Modal isOpen={modal} toggle={tog} className={className} >
        <ModalHeader toggle={tog}>Notification<span className="text-danger mx-3">(New)</span><span className="ml-5 pl-5">{currDate} </span> </ModalHeader>
       {not}
        
      </Modal>   
    { /*   <NavItem key="103">
          <NavLink  href="/Shows" className =" mx-2 py-1" ><TvSharpIcon/></NavLink>
        </NavItem>
        <NavItem key="104">
          <NavLink className =" mx-2 py-1" onClick={absSearch} style={{cursor:"pointer"}} ><SearchSharpIcon/></NavLink>
    </NavItem>*/}
        {search}
            </ Nav>
           
  </Navbar>
  <style>
    {
      `.MuiSelect-select.MuiSelect-select {
        padding-right: 7px;}
        .MuiPopover-paper {
            top:85px!important;
            left:0px!important;
            max-width: 100%important;
        }
        .MuiInput-underline:before {
          bottom:-10px;
         
        }
        .MuiInput-underline:after {
          border-bottom: 2px solid #dadbdb;
        }
        .MuiInput-underline{
        height:35px;
      }
            .MuiMenu-list {
                font-size: 15px;
    font-weight: 500;
    height: 42px;
    overflow: visible;
    width:100%;
    display: flex;
   padding:0px;
    overflow-x:scroll;
}
.MuiPopover-paper {
    max-width: 100%!important;
    overflow-x:scroll;
    display: flex;
}
.MuiPaper-elevation8 {
    border-radius:unset;
    box-shadow: 0px 0px 5px -3px rgb(0 0 0 / 20%),  0px 0px 14px 2px rgb(0 0 0 / 0%);
    padding:1px 1rem;
}
 .navbar-nav .nav-item.active .nav-link:before{
  border-bottom: 1px solid rgba(0, 0, 0, 0.42);
}

        .modal-content
      {
        max-height:255px;
      }}`
    }
  </style>
    </div>
    )
}
export default SliderMenu;