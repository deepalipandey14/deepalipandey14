import {useState,useEffect} from "react"
import SinglePageBlog from './page/SinglePageBlog'
import axios from 'axios';
//import Last from './Home/Last';
import { Helmet } from 'react-helmet';

const News=(props)=>
{
    const [title, setTitle]=useState();
    const [date, setdate]=useState();
    const [fName, setFname]=useState();
    const [mName, setMname]=useState();
    const [lName, setLname]=useState();
    const [img, setImg]=useState();
    const [shortDes, setShortDes]=useState();
    const [longDes, setLongDes]=useState();
    const [Id, setId]=useState();
   // const [cat, setCat]=useState();
    //const [counter, setCounter]=useState();
    //let count=0,len;  
    try{
        useEffect(() => {
    
        async function getData()
        {  
        
            const res = await axios.get(`https://panel.jagratjantanews.com/api/News/GetDetails?url=${props.match.params.name}`)
            setId(res.data.Id)
          setTitle(res.data.Title); 
          setdate(res.data.CreatedOn);
          setFname(res.data.CreatedByFirstName);
          setMname(res.data.CreatedByMiddleName);
          setLname(res.data.CreatedByLastName);
          setImg(res.data.CoverImage)
          setShortDes(res.data.ShortDescription)
          setLongDes(res.data.LongDescription)
          //setCat(res.data.CategoriesList[0].Url)
        
        }
        getData();  
      
      });}catch(err)
      {
        console.log(err)
      }
    return(
        <div>
            <Helmet>
        <title>{props.match.params.name}</title>
      </Helmet>
    {/*view={counter} */}
            <SinglePageBlog newsValue2={longDes} 
title={title} fName ={fName} mName={mName}lName={lName}date={date} src={img} newsValue={shortDes}
           cat={props.match.params.cname} sub={props.match.params.subname}  Id={Id} parurl={props.match.params.name}/> 
           
        </div>
    )
}
export default News;