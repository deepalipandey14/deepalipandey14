import NewDiv from "./NewDiv"
import React, {useState,useEffect} from 'react';
import axios from 'axios';
const Section6=(props)=>
{
    
    const [cattitle, setCatTitle]= useState();
  try{
    useEffect(() => {
        async function getData()
        {let a        
             const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.name}`)
            
             const cat =res1.data.NewsList.map((c,i)=>
            {
                if(i>=props.fv && i<=props.lv)
                {
                a=  <NewDiv key={i} sub={props.sub} cat={props.name}href={c.Url} value={c.Title}/>
                }
                else{
                    a= null
                }
                return a;    
            })
             setCatTitle(cat) 
            }
        getData();
    })}catch(err)
    {
      console.log(err)
    }
    return(
<div>
{cattitle}
</div>
        
    )
}
export default Section6;