import React,{useState,useEffect} from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardMedia from '@material-ui/core/CardMedia';
import './card.css';
import axios from 'axios';
const useStyles = makeStyles({
    root: {
      maxWidth:420,
    },
  });
 
const SideCard=( props )=>{
  const [liveVideo, setLiveVideo]= useState();
  useEffect(() => {
    async function getData1()
    {
      const res = await axios.get(`https://panel.jagratjantanews.com/api/LiveVideo/Get`)
      setLiveVideo(res.data.VideoUrl)
    }
    getData1();
  })
    const classes = useStyles();    
    return (
     <div className="mt-4"> 
<Card className={classes.root}  >
      <CardActionArea  >
          <a href={liveVideo}>
        <CardMedia
          component="img"
          height="230"
          alt="News"
          
          src={props.src}
        
        /></a>
     
      </CardActionArea>
      
      
    </Card>
    </div>
    
    )
}
export default SideCard;