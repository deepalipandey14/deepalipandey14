import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import './card.css';
const useStyles = makeStyles({
    root: {
      marginTop:10,
    },
  });
    
const SideCard1=(props)=>
{
    const classes = useStyles();  
    return (
        <Card className={classes.root} >
      <CardActionArea >
        <CardMedia
          component="img"
          height="200"
          alt="News"
          src={props.src} 
        />
        <CardContent className="text-decoration-none"> 
        <Typography variant="body2" style={{color:"#0000008c"}}className=" font-weight-bold" >
        {props.heading} </Typography>
        <Typography variant="body2" style={{color:"#0000008c"}}component="span" className="small my-2 pb-2" >by
       <Typography className="text-danger " component="span"   variant="span"> {props.editorName}</Typography> <Typography component="span" style={{color:"#0000008c"}}className="float-sm-right small" variant="span"> {props.date}</Typography></Typography>    
          <Typography variant="body2" style={{color:"#0000008c"}} component="span">  
          {props.title}
          </Typography>
        </CardContent>
      </CardActionArea>
      
      
    </Card>
    )
}
export default SideCard1;