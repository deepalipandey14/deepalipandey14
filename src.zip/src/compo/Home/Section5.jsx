import React, {useState,useEffect} from 'react';
import Bg from '../page/BgCompo';
import axios from 'axios';
const Section5=(props)=>{

const [cattitle, setCatTitle]= useState();
 try{
useEffect(() => {
    async function getData()
    {         
         const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.name}`)
         const cat = res1.data.NewsList.map((c,i)=>
         {
           if(i===0)
           {
           return<Bg key={i} sub={props.sub}cat={props.name}href={c.Url} title={c.Title} img={c.CoverImage} fName={c.CreatedByFirstName}mName= {c.CreatedByMiddleName} lName={c.CreatedByLastName} date={c.CreatedOn}/>
           }
    })
         setCatTitle(cat) 
        }
    getData();
})}catch(err)
{
  console.log(err)
}

return(
    <div>   
        {cattitle}
    
    </div>
)
}
export default Section5;