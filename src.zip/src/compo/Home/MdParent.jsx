import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import './card.css';

const useStyles = makeStyles({
    root: {
      maxWidth:192,
      marginTop:15,  
    },
  });
  
const MdParent=( props )=>{
    const classes = useStyles();    

    return (
        
<Card className={classes.root} >
      <CardActionArea >
        <CardMedia
          component="img"
          height="140"
          alt="News"
          src={props.img}
        
        />
        <CardContent>
          <Typography variant="body2" style={{maxHeight:"80px",minHeight:"80px",overflow:"hidden",color:"#0000008c"}} component="span"className="pt-1 font-weight-bold">
          {props.title}
          </Typography>
        </CardContent>
      </CardActionArea>
      
    </Card>
    
    )
}
export default MdParent;