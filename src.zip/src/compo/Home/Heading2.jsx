import React from 'react'
import { Typography } from '@material-ui/core';
const Heading2=(props)=>
{
    return (
        <div className="text-center">
            <Typography component="h2" variant="body2" className="mt-3 border-bottom font-weight-bold border-secondary mb-3 medium" style={{fontSize:"18px"}}>
         {props.value1}<Typography variant="body2" component="span" className="font-weight-bold"style={{color:"red",fontSize:"18px"}}>{props.value2}</Typography>
         </Typography>
        </div>
    )
}
export default Heading2;