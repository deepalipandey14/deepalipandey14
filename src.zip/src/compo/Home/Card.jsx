import React, {useState,useEffect} from 'react';
import { Row, Col } from 'reactstrap';

import { Swiper, SwiperSlide } from "swiper/react";  
  // Import Swiper styles
  import "swiper/swiper.min.css";
  import "swiper/components/pagination/pagination.min.css"
  import "../Categori/flickity.css";
  // import Swiper core and required modules
  import SwiperCore, {
    Pagination
  } from 'swiper/core';
import './card.css';
import CardList from './CardList';

import { useMediaQuery } from 'react-responsive';
import axios from 'axios';
import Slider from '../Categori/Slider';
SwiperCore.use([Pagination]);
export default function ImgMediaCard(props) {
  const [topTitle, setTopTitle]= useState();
  try{
  useEffect(() => {
    async function getData()
    {
      //const res1 = await axios.get(`https://panel.jagratjantanews.com/api/Menu/GetAll`)
        const res = await axios.get(`https://panel.jagratjantanews.com/api/News/AllNews`)
        const cat = res.data.NewsList.map((cvalue,i)=>
        {
        
       return i<=3 ?<Col md={3}sm={6} xs={6}> 
           <CardList cat="Updates" sub={cvalue.NewsType} title={cvalue.Title} img={cvalue.CoverImage} href={cvalue.Url} /></Col>:null     
          
        })
           setTopTitle(cat); 
           
    }
    getData();
  });}catch(err)
  {
    console.log(err)
  }
  const dis = useMediaQuery({ query: '(max-width: 1300px)' })
  const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
  return (<>
{isTabletOrMobile && <Row className="mt-2">
        {topTitle}
    </Row>}
  {dis && <Row className="mt-2"style={{display:"flex",flexDirection:"row",flexWrap: "nowrap",
    overflowX: "scroll"}}>
        {topTitle}
   
</Row>}
</>
  );
}