import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import './card.css';
const useStyles = makeStyles({
    root: {
      maxWidth:400,
      marginTop:10,
    },
  });
    
const SideCard2=(props)=>
{
    const classes = useStyles();  
    return (
        <Card className={classes.root} >
      <CardActionArea >
        <CardMedia
          component="img"
          height="200"
          alt="News"
          src={props.src}
        
        />
        <CardContent>
        
        <Typography variant="body2" className=" font-weight-bold" component="h6" variant="h6">
        {props.heading} </Typography>
        <Typography variant="body2" style={{color:"#0000008c"}} component="span" className="small my-2 pb-2" >BY
       <Typography className="text-danger " component="span"   variant="h6"> {props.editorName}</Typography> <Typography component="span" className="float-sm-right small"style={{color:"#0000008c"}} variant="h6"> {props.date}</Typography></Typography>    
          <Typography variant="body2" style={{color:"#0000008c"}} component="span">
          
          {props.title}
          </Typography>
        </CardContent>
      </CardActionArea>
      <CardActions>
      <Button size="small" color="primary" className="p-2" >
          share
        </Button>
        <Button size="small" color="primary">
          About More
        </Button>
      </CardActions>
      
    </Card>
    )
}
export default SideCard2;