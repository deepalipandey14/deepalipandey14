 import React from 'react'
 import { Typography } from '@material-ui/core';

 const Heading=(props)=>
 {
     return (
        
             <Typography component="h6" variant="body2" className="mt-3 border-bottom border-danger mb-3 medium font-weight-bold h6" style={{fontSize:"18px",flexDirection:"Row"}} >
          {props.value1}<Typography variant="body2" component="span" className="font-weight-bold h6"style={{color:"#cc0b18",fontSize:"18px",flexDirection:"Row"}}>{props.value2}</Typography>
          </Typography>
         
     )
 }
 export default Heading;