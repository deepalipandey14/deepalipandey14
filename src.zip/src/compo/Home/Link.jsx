import React from 'react';
import { Link } from '@material-ui/core';

const LinkRd=(props)=>
{
    return (<div>
        <Link to={`/users/${props.path}`} activeClassName="active">{props.value}</Link>
    </div>)
}
export default LinkRd;