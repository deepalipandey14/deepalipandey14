import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import './card.css';
import { Link } from '@material-ui/core';
const useStyles = makeStyles({
    root: {
      maxWidth:192,
      marginTop:15,  
    },
  });
const CardList=( props )=>{
    const classes = useStyles();
    let s
if(props.sub==="null")
{
  s="Story"
}else
{
  s=props.sub
}
    return (
      <Link href={`/${props.cat}/${s}/${props.href}`}catName={props.catName} className="text-decoration-none">
<Card className={classes.root}  >
      <CardActionArea >
        <CardMedia
          component="img"
          height="140"
          alt="News"
          src={props.img}
        
        />
        <CardContent >
          <Typography variant="body1"  component="span"className="pt-1 font-weight-bold">
            <div style={{maxHeight:"88px",overflow:"hidden",minHeight:"88px",color:"#0000008c"}}>{props.title}</div>
          
          </Typography>
        </CardContent>
      </CardActionArea>
      
    </Card>
    </Link>
    
    )
}
export default CardList;