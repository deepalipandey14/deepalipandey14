import React from 'react';
import { makeStyles} from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import Link from '@material-ui/core/Link';
const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    margin:"10px 0",
    backgroundColor: '#c3e6ea1f',
  },
  details: {
    display: 'flex',
    flexDirection: 'column',
    width: '-webkit-fill-available',

  },
    content: {
      flex: '1 0 auto',
    },
   mediaContant:{
       width:'35%'
   },
   fonth:
   {
       fontWeight:'bold',
       marginBottom:'10px',
       height: '20px',
       overflow: 'hidden',
       lineHeight: 'initial',
   },
  
  }));
  
  export default function SideMedia(props) {
    const classes = useStyles();
 let s
 try{
 if(props.sub==="null")
 {
   s="Story";
 }
 else{
   s=props.sub
 }}catch(err)
 {
   console.log(err)
 }
  
    return (
     
      <Link href={`/${props.cat}/${s}/${props.href}`} className="text-decoration-none">
      <Card className={classes.root}>
        <div className={classes.details}>
          <CardContent className={classes.content}>
            <Typography component="h6"variant="h6"className={classes.fonth}>
              {props.heading}
            </Typography>
            <Typography variant="body2" style={{fontSize:"0.875rem",overflow:"hidden",height: "38px",color:"#0000008c"}}>
              {props.value}
            </Typography>
          </CardContent>
          
        </div>
        </Card>
        </Link>
      
    );
  }
  