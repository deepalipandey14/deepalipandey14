import React, {useState,useEffect} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Alert from '@material-ui/lab/Alert';
import IconButton from '@material-ui/core/IconButton';
import Collapse from '@material-ui/core/Collapse';
import CloseIcon from '@material-ui/icons/Close';
import { Typography } from '@material-ui/core';
import Link from '@material-ui/core/Link';
import axios from 'axios';
const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
    '& > * + *': {
      marginTop: theme.spacing(2),
    },
  },
}));

export default function TransitionAlerts(props) {
  const [num, setNum]= useState();
  const [url, setUrl]= useState();
  const [open, setOpen] = React.useState(true);
  const [type, setType]= useState();
  let s;
  try{
  useEffect(() => {
      async function getData()
      {
       
       
          const res = await axios.get(`https://panel.jagratjantanews.com/api/BreakingNews/GetAll`)
        
          let len = res.data.NewsList.length
         
          if(len===0)
          {
            setOpen(false)
          }
          else{
            setUrl(res.data.NewsList[len-1].Url)
              setNum(res.data.NewsList[len-1].Title)
              setType(res.data.NewsList[len-1].NewsType)
            
         }
      }
      getData();
  });}catch(err)
  {
    console.log(err)
  }
  const classes = useStyles();
  if(props.sub===undefined)
              {
              s=type
          
              }
              else
              {
                s=props.sub
              }
  return (
    <div className={classes.root}>
    
      <Collapse in={open}>
        <Alert  className="py-0"icon={false} variant="filled" style={{borderRadius:"22px",overflow:"hidden",height:"36px",backgroundImage:"linear-gradient(#8e0000,#da4242)"}}
          action={
            <IconButton 
              aria-label="close"
              color="inherit"
              size="small"      
              onClick={() => {
                setOpen(false);
              }}
            >  
              <CloseIcon fontSize="inherit" />
            </IconButton>
          }
        >
          <Link href={`Breaking/${s}/${url}`} className="text-decoration-none text-white">
          <Typography component="span"className="h6"style={{lineHeight:"26px"}}>{props.value} | {num}</Typography>
         </Link>
        </Alert>
      </Collapse>
    
    </div>
  );
}