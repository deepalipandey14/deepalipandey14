import React from 'react'
import ReactPlayer from 'react-player'
const Media=(props)=>
{return(
  
<ReactPlayer
  url={props.url}
  width='100%'
/>
)}
export default Media;
