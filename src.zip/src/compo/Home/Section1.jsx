import React, {useState,useEffect} from 'react';
import { Row, Col} from 'reactstrap';
import SmCard from '../Home/SmCard';
import axios from 'axios';
import Section6 from './Section6';
const Section1=(props)=>
{
    const [cattitle, setCatTitle]= useState();
    try{
    useEffect(() => {
        async function getData()
        {let a
        
             const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.name}`)
            
             const cat =res1.data.NewsList.map((c,i)=>
            {
                if(i===0 || i===1)
                {
                a=<Col md="6" xs="12"><SmCard key={i}sub={props.sub} cat={props.name} src={c.CoverImage} title={c.Title} href={c.Url}/></Col>
            
                }
               
                else{
                    a= null
                }
                return a;
                
            })
             setCatTitle(cat)
            
            }
        getData();
    })}catch(err)
    {
      console.log(err)
    }
    return(
      
 <Row>
                <Col sm="5">
                <Section6 sub={props.sub}name={props.name} fv="2" lv="5"/>
            
                </Col>
                <Col sm="7">
                    <Row>
                   {cattitle}
                
                    </Row>
                </Col></Row>

    )
}
export default Section1;