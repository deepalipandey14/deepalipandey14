import { Divider} from '@material-ui/core';
import {
    Navbar,
    Nav,
    NavItem,
    NavLink
  } from 'reactstrap';

const NewDiv=(props)=>
{let s;
    if(props.sub==="null")
    {
        s="Story"
    }
    else
    {
        s=props.sub
    }
    return (
        <div>
            <Navbar light expand="md" className="p-0 h6" style={{fontSize:"15px"}}>
         <Nav className="mr-auto " nav style={{fontSize:"14px",fontWeight:"bold",display:"inline-block"}}>
            <NavItem>
            <NavLink href={`/${props.cat}/${s}/${props.href}`}  className="p-0 mx-1"style={{height:"46px",overflow:"hidden",lineHeight:"22px"}} >{props.value}</NavLink>
            </NavItem>
            <Divider/>
                </Nav>
                </Navbar>
        </div>
    )
}
export default NewDiv;