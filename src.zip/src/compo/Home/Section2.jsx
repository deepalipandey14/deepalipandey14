import React, {useState,useEffect} from 'react';
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css"
import "swiper/components/navigation/navigation.min.css"
// import Swiper core and required modules
import SwiperCore, {
  Pagination,Navigation
} from 'swiper/core';

import { Row, Col} from 'reactstrap';
import axios from 'axios';
import CardList from './CardList';
import { useMediaQuery } from 'react-responsive';
import '../Categori/flickity.css';
// install Swiper modules
SwiperCore.use([Pagination,Navigation]);
const Section2=(props)=>
{
    const [news1, setNews1]= useState();    
    const [monews1, setMoNews1]= useState(); 
    try{
    useEffect(() => {
        async function getData()
        {
            const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.name}`)
            const cat = res1.data.NewsList.map((c,i)=>
            {
                if(i<4 ){ 
                 
                return <Col md={3}sm={6} xs={6}className="abb">
                <CardList key={i}sub={props.sub} cat={props.name}title={c.Title} img={c.CoverImage} href={c.Url} catName={props.name}/>
            </Col>

          
            }
            else
            {
             return  null
            }
            })
            setNews1(cat)
        }
        getData();
    })}catch(err)
    {
      console.log(err)
    }
    const dis = useMediaQuery({ query: '(max-width: 1300px)' })
    const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
    return(<div>
               {isTabletOrMobile &&   <Row style={{display:"flex",flexDirection:"row"}}> 
       
              {news1}       
         
                       
            </Row>}
    {  /*      {dis && <Row style={{display:"flex",flexDirection:"row",flexWrap: "nowrap",
    overflowX: "scroll"}}className="px-3"> 
    <Swiper pagination={true} className="mySwiper">
              <SwiperSlide>  {news1}       
</SwiperSlide>
</Swiper>

                   
  


            </Row>}
            
    */ }
         {dis && <Row style={{display:"flex",flexDirection:"row",flexWrap: "nowrap",
    overflowX: "scroll"}}className="px-3"> 
 

  {news1} 
     
</Row>}
<style>
  {
    `.abb
    {
      animation: slider 15s infinite;
    }
    }
    @keyframes slider {
      0%, {left:0%; top:0%;}
      
      50%{left:100%; top:0%;}
      75%{left:0%; top:0%;}
      100%{left:100%; top:0%;}
      
  }`
  }
</style>
            </div>

    
    )
}
export default Section2;