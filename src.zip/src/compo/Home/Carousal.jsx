import React, {useState,useEffect} from 'react';
import { UncontrolledCarousel } from 'reactstrap';
import axios from 'axios';
import { Link } from '@material-ui/core';
const Carousal = (props) =>

{
  const [showimg1, setShowImg1]=useState();
  const [showimg2, setShowImg2]=useState();
  const [showimg3, setShowImg3]=useState();  
  const [showimg4, setShowImg4]=useState();
  const [showimg5, setShowImg5]=useState();
  const [showheading5, setShowHeading5]=useState();
  const [showheading4, setShowHeading4]=useState();
  const [showheading1, setShowHeading1]=useState();
  const [showheading2, setShowHeading2]=useState(); 
  const [showheading3, setShowHeading3]=useState();
  const items = [
    {
      src: `${showimg1}`,
      altText: `${showheading1}`,
      caption: ' ',
      header: `${showheading1}`,
      key: '1'
    },
    {
      src: `${showimg2}`,
      altText: `${showheading2}`,
      caption: '',
      header: `${showheading2}`,
      key: '2'
    },   {
      src: `${showimg3}`,
      altText: `${showheading2}`,
      caption: '',
      header: `${showheading3}`,
      key: '3'
    },   {
      src: `${showimg4}`,
      altText: `${showheading4}`,
      caption: '',
      header: `${showheading4}`,
      key: '4'
    },   {
      src: `${showimg5}`,
      altText: `${showheading5}`,
      caption: '',
      header: `${showheading5}`,
      key: '5'
    },
  ];
 try{
  useEffect(() => {

    async function getData()
    {
      const res = await axios.get(`https://panel.jagratjantanews.com/api/Show/GetAll`)
     res.data.ShowList.map((c,i)=>
      {
       if(i===0)
       {
        setShowImg1(c.ImagePath)
        setShowHeading1(c.Title)
       } 
       if(i===1)
       {
        setShowImg2(c.ImagePath)
        setShowHeading2(c.Title)
       }
       if(i===2)
       {
        setShowImg3(c.ImagePath)
        setShowHeading3(c.Title)
       }
       if(i===3)
       {
        setShowImg4(c.ImagePath)
        setShowHeading4(c.Title)
       }
       if(i===4)
       {
        setShowImg5(c.ImagePath)
        setShowHeading5(c.Title)
       }
       
       
      })
     
    } 
    getData();
}); }catch(err)
{
  console.log(err)
}


return (
  
  <div >
          <Link href="/Shows"  className="text-decoration-none">
<UncontrolledCarousel items={items}/> </Link>
<style>
  {
    `.carousel-caption
    {
      overflow:hidden;
      height:90px;
      padding-top:40px;

    }
    .carousel
    {
      height:390px;
    }
    .carousel-item
    {
      width: 100%;
    } .carousel-item img
    {
      min-height:350px;
      max-height:350px;    
    }
    @media screen and (max-width:1300px)
    {
      .carousel-item img
      {
        min-height:250px;
        max-height:250px;  
      }
      .carousel
      {
        height:276px;
      }
    }
  }
  .carousel-caption {
    color:#8e0000;
  }
    .carousel-caption h3
    {
      color:#8e0000;
    }
    .carousel {
      background: none!important;
    }
    .carousel-indicators li{
     width:7px;
     height:7px;
     border-radius:50% ;
    }
    .carousel-indicators
    {
      padding-bottom:40px;
    }
    .carousel-caption 
    {
      position:relative;
      left:0%;
      padding-top:30px;
    }
    .carousel-control-prev, .carousel-control-next {
      display:none;
    }
    `
  }
</style>
  </div>
)
} 

export default Carousal;