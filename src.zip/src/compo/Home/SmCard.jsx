import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import './card.css';
import Link from '@material-ui/core/Link';
import IconPage from '../page/IconPage';
const useStyles = makeStyles({
    root: {
      marginTop:5,
      height:250,
    },
  });
  
const SmCard=( props )=>{
    const classes = useStyles();   
    let s 
if( props.sub==="null")
{
  s="Story"
}
else{
  s=props.sub
}
    return (
      <Link href={`/${props.cat}/${s}/${props.href}`} className="text-decoration-none">
<Card className={classes.root} >
     
        <CardMedia
          component="img"
          height="120"
          alt="News"
          src={props.src}
        
        />
        <CardContent>
          <Typography variant="body1" component="span" >
          <div className="font-weight-bold"style={{color:"#000000a1",height:"65px",overflow:"hidden"}}>{props.title}</div>
          </Typography>
        </CardContent>
        <IconPage/>
    </Card>
    </Link>
    )
}
export default SmCard;