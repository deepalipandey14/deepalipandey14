import React, {useState,useEffect} from 'react';
import Last from './Last'
import axios from 'axios';

const LCompo=(props)=>
{
    const [cattitle, setCatTitle]= useState();
  try{
    useEffect(() => {
        async function getData()
        {let a        
             const res1 = await axios.get(`https://jjn.ascentrek.co.in/api/News/GetByCategory?url=haldwani`)
            
             const cat =res1.data.NewsList.map((c,i)=>
            {
                if(i<=3)
                {
                a=  <Last href={c.Url} src={c.CoverImage}heading={c.Title}/>
            
                }
               
                else{
                    a= null
                }
                return a;
                
            })
             setCatTitle(cat)
            
            }
        getData();
    })}catch(err)
    {
      console.log(err)
    }
    return(<div>
        {cattitle}
    </div>)
}
export default LCompo;