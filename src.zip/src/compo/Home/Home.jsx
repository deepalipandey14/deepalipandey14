import React,{useState,useEffect} from 'react'
import {Container,Row,Col} from 'reactstrap';
import Container1 from './Container1';
import live from '../../images/live.png'
import Heading from './Heading'
import {Typography} from '@material-ui/core';
import SideCard from './SideCard';
import { useMediaQuery } from 'react-responsive';
import Ad from '../Ad';
//import ad1 from '../../images/ad1.png';
//import Heading2 from './Heading2';
//import BlogCard from './BlogCard';
import axios from 'axios';
import Live from '../Live';
import Section3 from './Section3';
import Collapse from '@material-ui/core/Collapse';
import Section6 from './Section6';
import Section5 from './Section5';
const currDate = new Date().toLocaleDateString();
const currTime = new Date().toLocaleTimeString("en-US");
{ /* const [cattitle, setCatTitle]= useState();
    const [date, setDate]= useState();
    const [url, setUrl]= useState();
    const [fName, setFName]= useState();
    const [lName, setLName]= useState();
  const [mName, setMName]= useState();
const [img, setImg]= useState();*/}
const Home=(props)=>
{
  
    const [liveNews, setLive]= useState();
    const [liveShortDes, setLiveShortDes]= useState();
    const [liveDate, setLiveDate]= useState();
    const [LfName, setLiveFName]= useState();
    const [LlName, setLiveLName]= useState();
    const [LmName, setLiveMName]= useState();
    const [liveImg, setLiveImg]= useState();
    const [liveUrl, setLiveUrl]= useState();
    const [open, setOpen] = React.useState(true);

    const [type, setLiveType]= useState();
  
    const [ad2, setAd2]= useState();
    const [ad3, setAd3]= useState(); 
    const [adBottom, setAdBottom]= useState();
    try{
    useEffect(() => {
        async function getData1()
        {  
            const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/AllNews`)
            const add1 = await axios.get(`https://panel.jagratjantanews.com/api/AdvertiseHome/MiddleTop`)
            setAd2( add1.data.AdvertisePath)
            const add2 = await axios.get(`https://panel.jagratjantanews.com/api/AdvertiseHome/MiddleBottom`)
            setAd3( add2.data.AdvertisePath)
            const addbottom = await axios.get(`https://panel.jagratjantanews.com/api/AdvertiseHome/Bottom`)
            setAdBottom( addbottom.data.AdvertisePath)
            let count =0
            for(let i=0; i<res1.data.NewsList.length;i++){        
            if(res1.data.NewsList[i].IsLiveNews===(true))
            {
              setLive(res1.data.NewsList[i].Title)
              setLiveShortDes(res1.data.NewsList[i].ShortDescription)
              setLiveDate(res1.data.NewsList[i].CreatedOn)
              setLiveFName(res1.data.NewsList[i].CreatedByFirstName)
              setLiveLName(res1.data.NewsList[i].CreatedByLastName)
              setLiveMName(res1.data.NewsList[i].CreatedByMiddleName)
              setLiveImg(res1.data.NewsList[i].CoverImage)
              setLiveType(res1.data.NewsList[i].NewsType)
              setLiveUrl(res1.data.NewsList[i].Url)
              count++;
            }  
           
        {/*    if(i===0){
                setCatTitle(res1.data.NewsList[i].ShortDescription)
                setDate(res1.data.NewsList[i].CreatedOn)
                setFName(res1.data.NewsList[i].CreatedByFirstName)
                setLName(res1.data.NewsList[i].CreatedByLastName)
                setMName(res1.data.NewsList[i].CreatedByMiddleName)
                setImg(res1.data.NewsList[i].CoverImage)
                setUrl(res1.data.NewsList[i].Url)
            }*/}
        }
        if(count===0)
        {
            setOpen(false)
        }
    }
        getData1();
    });}catch(err)
    {
      console.log(err)
    }
    const dis = useMediaQuery({ query: '(max-width: 1300px)' })
    const isTabletOrMobile = useMediaQuery({ query: '(min-width: 1300px)' })
    return (
        <div>


            {isTabletOrMobile && <Container fluid={true}style={{paddingRight:"80px",paddingLeft:"90px"}}>
                <Row>
                    <Col sm={8}> <Container1/>
                    </Col>
                    <Col sm={4}>
                    <div className="text-center">{currDate} {currTime}
                    </div>
                    <SideCard src={live}/>
                    <Collapse in={open}>
                    <Heading value1="Live" value2="News"/>
                    <Typography className="h2 py-2" style={{fontSize:"20px",fontWeight:"600",maxHeight:"68px",overflow:"hidden"}}>{liveNews}</Typography>
                    
               <Live type={type}href={liveUrl}src={liveImg} fName={LfName}mName= {LmName} lName={LlName} date={liveDate} title={liveShortDes}/>
             
              </Collapse>
             <div className="col-md-12 adAd2" >
              <Ad ad={ad2}/></div> 
          <Heading value1="खे" value2="ल"/>
            <Section3 name="sports" sub="null"/>
            <Heading value1="एंटरटेन" value2="मेंट" />
                <Section6 name="entertainment" sub="null" fv="0" lv="3"/>
                    <Heading value1="JJN की" value2=" कलम" />
                    <div className="col-md-12 adAd2" > <Ad ad={ad3}/></div>
                   
             { /*      <Heading value1="टेक्नो" value2="लॉजी"/>
         <Section5 name="technology" sub="null" v="0"/>*/}
                    <Heading value1="दुनि" value2="या"/>
                        <Section5 sub="null"name="duniya"fv="0" lv="2"/>        
            <div className="mt-4">
          </div>
                    </Col>
                </Row>
           {/* <div style={{backgroundColor:"#d4dbf71f"}}>
            <Heading2 value1="ब्लॉ" value2="ग"/>
            <BlogCard/>
            </div>*/}
            <div className="col-sm-10 adTop ">
            <Ad ad={adBottom}/>
            </div>
    </Container>}
           {dis &&  <Container fluid={true} style={{ marginTop:"50px"}}>
           <Row>
                    <Col sm={8}style={{paddingRight:"30px",paddingLeft:"30px"}}> <Container1/>
                    </Col>
                   
                    <Col sm={4}>
                    
                    {/*<SideCard src={live}/>*/}
                    <Collapse in={open}>
                    <Heading value1="Live" value2="News"/>
                    <Typography className="h2 py-2" style={{fontSize:"20px",fontWeight:"600",maxHeight:"68px",overflow:"hidden"}}>{liveNews}</Typography>
              
                    
               <Live href={liveUrl} type={type} src={liveImg} fName={LfName}mName= {LmName} lName={LlName} date={liveDate} title={liveShortDes}/>
             
              </Collapse>
              <div className="col-md-12 adAd2" >
               <Ad ad={ad2}/>
                </div>
               <Heading value1="खे" value2="ल"/>
            <Section3 name="sports" sub="null"/>
            <Heading value1="एंटरटेन" value2="मेंट" />
                <Section6 name="entertainment" sub="null"fv="0" lv="3"/>
                    <Heading value1="JJN की" value2="कलम " />
                    <div className="col-md-12 adAd2" >
                    <Ad ad={ad3}/></div>
                 { /*  <Heading value1="टेक्नो" value2="लॉजी"/>
         <Section5 name="technology" sub="null"v="0"/>*/}
                    <Heading value1="दुनि" value2="या"/>
                        <Section5 name="duniya"sub="null"fv="0" lv="2"/>
            <div className="mt-4">
          </div>
                    </Col>
                </Row>
          {/*  <div style={{backgroundColor:"#d4dbf71f"}}>
            <Heading2 value1="ब्लॉ" value2="ग"/>
            <BlogCard/>
    </div>*/}
    <div className="col-sm-10 adTop ">
            <Ad ad={adBottom}/>
            </div>
       </Container>}
       <style>
           {
               `.MuiTypography-h6 {
                   font-family:font-family: 'Faustina', serif;
               }
               `
           }       </style>
        </div>
    )
}
export default Home;