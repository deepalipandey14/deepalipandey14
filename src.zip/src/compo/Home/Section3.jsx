import React, {useState,useEffect} from 'react';
import axios from 'axios';
import SideMedia from './SideMedia';
const Section3=(props)=>
{
    const [value,setValue]= useState();
    try{
    useEffect(() => {
      async function getData()
      {
           let a
           const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.name}`)
          const cat = res1.data.NewsList.map((c,i)=>
          {
              a=i<=2?<SideMedia key={i} sub={props.sub} cat ={props.name}href={c.Url} heading={c.Title} value={c.ShortDescription} />:null
           return a
          })
          setValue(cat)
        }
      getData();
  })}catch(err)
  {
    console.log(err)
  }
    return(
        <div>
          {value}
            
        </div>
    )
}
export default Section3;