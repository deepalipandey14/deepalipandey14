import React, {useState,useEffect} from 'react';
import {Row, Col} from 'reactstrap';
import Sideard from './Sideard';
import Section5 from '../Home/Section5'
import axios from 'axios';
const Section=(props)=>
{
    
    const [cattitle1, setCatTitle1]= useState();
    const [url1, setUrl1]= useState();
    const [img1, setImg1]= useState();
    const [value, setti]= useState();
    const [cattitle2, setCatTitle2]= useState();
    const [url2, setUrl2]= useState();
    const [img2, setImg2]= useState();
    const [value2, setti2]= useState();
    const [cattitle3, setCatTitle3]= useState();
    const [url3, setUrl3]= useState();
    const [img3, setImg3]= useState();
    const [value3, setti3]= useState();
    const [cattitle4, setCatTitle4]= useState();
    const [url4, setUrl4]= useState();
    const [img4, setImg4]= useState();
    const [value4, setti4]= useState();
try{
    useEffect(() => {
        async function getData()
        {
             let NewsUrl
             const res1 = await axios.get(`https://panel.jagratjantanews.com/api/News/GetByCategory?url=${props.name}`)
             for(let j=0;j<res1.data.NewsList.length;j++){
                NewsUrl= res1.data.NewsList[j].Url;
                const res3 =await axios.get(`https://panel.jagratjantanews.com/api/News/GetDetails?url=${NewsUrl}`)
  
                 if(j===1){
                    setCatTitle1(res3.data.ShortDescription)
                    setUrl1(res3.data.Url)
                    setti(res3.data.Title)
                    setImg1(res3.data.CoverImage)

                 }
                  if(j===2){
                    setCatTitle2(res3.data.ShortDescription)
                    setUrl2(res3.data.Url)
                    setti2(res3.data.Title)
                    setImg2(res3.data.CoverImage)

                 }
                  if(j===3){
                    setCatTitle3(res3.data.ShortDescription)
                    setUrl3(res3.data.Url)
                    setti3(res3.data.Title)
                    setImg3(res3.data.CoverImage)

                 }
                 if(j===4){
                    setCatTitle4(res3.data.ShortDescription)
                    setUrl4(res3.data.Url)
                    setti4(res3.data.Title)
                    setImg4(res3.data.CoverImage)
                 }   
             }
            }
        getData();
    });}catch(err)
    {
      console.log(err)
    }
return (
    <div style={{backgroundColor:""}}>
         <Row>
               <Col sm="6">
               <Section5 name={props.name} sub={props.sub} />
               </Col>
               
               <Col sm="6">
               <Sideard sub={props.sub} cat={props.name}src={img1}href={url1} heading={value} value={cattitle1}/>
               <Sideard sub={props.sub} cat={props.name}src={img2}href={url2} heading={value2} value={cattitle2}/>
                   </Col>
               
               </Row> 

               <Row>
                   <Col sm="6">
                   <Sideard sub={props.sub} cat={props.name} src={img3}href={url3} heading={value3} value={cattitle3}/>
                   </Col>
                   <Col sm="6">
                   <Sideard sub={props.sub}cat={props.name} src={img4} href={url4}heading={value4} value={cattitle4}/>
                   </Col>
               </Row>
    </div>
)
}
export default Section;