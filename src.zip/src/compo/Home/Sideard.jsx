import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import Link from '@material-ui/core/Link';
import IconPage from '../page/IconPage';
const useStyles = makeStyles((theme) => ({
    root: {
      display: 'flex!important',
      margin:"10px 0",
    },
    details: {
      display: 'flex',
      flexDirection: 'column',
      maxWidth:'70%',
    
    },
    content: {
      flex: '1 0 auto',
    },
   mediaContant:{
       maxWidth:'30%',
       flex: 'auto',
   },
   fonth:
   {
       fontWeight:'bold',
       height:43,
       overflow:'hidden',
   },
  
  }));
  
  export default function Sideard(props) {
    const classes = useStyles();
    let s
    if(props.sub === "null")
    {
      s="Story"
    }
    else{
      s=props.sub
    }
    return (
      <Link href={`/${props.cat}/${s}/${props.href}`}  className="text-decoration-none">
      <Card className={classes.root}>
        <div className={classes.details}>
          <CardContent className={classes.content}>
            <Typography component="h6"className={classes.fonth}>
              {props.heading}
            </Typography>
            <Typography  style={{fontSize:"0.87rem", height:40,
    overflow:'hidden',color:"#0000008c"}}>
              {props.value}
            </Typography>
          </CardContent>
          <div className="mb-2"><IconPage /></div> 
        </div>
        <CardMedia className={classes.mediaContant}
          component="img"
          height="auto"
          alt="News"
          src={props.src}
        
        />
      </Card>
      </Link>

    );
  }
  