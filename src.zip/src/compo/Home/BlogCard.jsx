import React from 'react';
import { Row, Col } from 'reactstrap';

import './card.css';
import BlogCardList from './BlogCardList';
import img12 from '../../images/img12.png'
import img2 from '../../images/img2.png'
import img14 from '../../images/img14.png'
import img4 from '../../images/img4.png'
export default function BlogCard(props) {
  

  return (
    <Row>
        <Col xs="6" sm="3">
        <BlogCardList id="1" src={img12} alt="News_1"  title="सर्दी के मौसम में लोगों को राहत देने निकले जमीयत उलेमा हिन्द के सदस्य"/>
        </Col><Col xs="6" sm="3">
       <BlogCardList id="2" src={img2} alt="News_2"title="सर्दी के मौसम में लोगों को राहत देने निकले जमीयत उलेमा हिन्द के सदस्य"/>
          </Col><Col xs="6" sm="3">
          <BlogCardList id="3" src={img14} alt="News_3" title="सर्दी के मौसम में लोगों को राहत देने निकले जमीयत उलेमा हिन्द के सदस्य"/>
          </Col> <Col xs="6" sm="3">
          <BlogCardList id="4" src={img4} alt="News_4" title="सर्दी के मौसम में लोगों को राहत देने निकले जमीयत उलेमा हिन्द के सदस्य"/>
          </Col>
    </Row>
   
  );
}