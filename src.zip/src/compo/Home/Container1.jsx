import {  Typography } from '@material-ui/core';
import {  Row, Col} from 'reactstrap';
import Alert from './Alert';
//import Media from './Media';
import Card from './Card';
import Heading from './Heading'
import Section from './Section';
import Section1 from './Section1';
import Section2 from './Section2';
import Carousal from './Carousal';
import Flickity from '../Categori/Slider';
import Slider from '../Categori/Slider';
const Container1 = (props) => {
  return (
      <div>

    <Row className=" py-2 mt-2">
      
          <Typography className="h2 py-2" style={{fontSize:"21px"}}> Welcome to <Typography style={{fontSize:"21px",color:"#c02b2b"}} className="font-weight-bold font-italic " component="span" >JJN News,</Typography></Typography>
        <Alert value="Breaking News " />
        
        <Col sm={12} className="py-2 px-0" style={{width:"100%"}}>
      
         <Carousal/>
         <Heading value1="अप" value2="डेट"/>
          <Card/> 
         
     
          <Heading value1="उत्तरा" value2="खंड"/>
    <Section name="uttarakhand" sub="null"/>
               <Heading value1="दे" value2="श"/>
              <Section1 name="desh" sub="null"/>
                <Heading value1="राज" value2="नीति"/>
                <Section2 name="rajniti" sub="null"/>
                <Heading value1="धार्मि" value2="क"/>
                <Section name="dharmik" sub="null"/>
                      <Heading value1="टेक्नो" value2="लॉजी"/>
                      <Section1 name="technology" sub="null"/>
                      <Heading value1="बिज़" value2="नेस "/>
                      <Section2 name="business" sub="null"/>
           <Heading value1="एजुके" value2="शन"/>
            <Section1 name="education" sub="null"/>
            </Col>
      </Row> <style> 
      {`.makeStyles-root-2 {
    display: inline-block;}
    .carousel {
      background: #EEE;
    }
    
    .carousel-cell {
      width: 66%;
      height: 200px;
      margin-right: 10px;
      background: #8C8;
      border-radius: 5px;
      counter-increment: carousel-cell;
    }
    
    /* cell number */
    .carousel-cell:before {
      display: block;
      text-align: center;
      content: counter(carousel-cell);
      line-height: 200px;
      font-size: 80px;
      color: white;
    }
    
    
    
    `}
    </style></div>)
}
export default Container1;