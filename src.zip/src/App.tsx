import React from 'react';
import { 
  BrowserRouter as Router, 
  Route, 
  Switch
} from 'react-router-dom'; 
import './App.css';
//import Homee from './compo/Home/Homee';
import Category from './compo/Haldwani/Category';
import Contact from './compo/Contact/Contact';
//import News from './compo/News';
import SignUP from './compo/page/SignUp';
import Login from './compo/page/Login';
import P404 from './compo/page/P404';
import Search from './compo/page/Search';
import Policy from './compo/page/Policy';
import Loadable from "react-loadable";
import { Spinner } from 'reactstrap';
import { Redirect } from "react-router-dom";
import Helmet from 'react-helmet';
import Shows from './compo/page/Show/Shows'
import Episode from './compo/page/Show/Episode';
import FireBase from './compo/page/FireBase';
const Home =Loadable({
  loader: ()=> import ('./compo/Home/Home'),
  loading: ()=> <div className="text-center my-5">Loading.....<Spinner style={{color:"8e0000"}} /></div>
})
const About =Loadable({
  loader: ()=> import ('./compo/page/About'),
  loading: ()=> <div className="text-center my-5">Loading.....<Spinner style={{color:"8e0000"}} /></div>
})
const News =Loadable({
  loader: ()=> import ('./compo/News'),
  loading: ()=> <div className="text-center my-5">Loading.....<Spinner style={{color:"8e0000"}} /></div>
})

const App=()=> {
  const msg = FireBase.messaging();
 msg.requestPermission().then(()=>
 {
   return msg.getToken();
 }
 ).then ((data)=>
 {
console.log("Token",data)
 })

  const a= true;
  const domain="https://jjn.ascentrek.co.in";
  return (
    <div >
       <Helmet>
       <meta charSet="UTF-8"/>
  <title>J.J.N. News: Latest News,Haldwani News India News, World News, Opinion, Politics, Governance, Defence, Economy, Education</title>
  <meta name="description" content="J.J.N. News" />
  <meta name="theme-color" content="#008f68" />
  
</Helmet>
       <Router >
        <Switch>
        <Route exact path="/About" >
  {a ? <About d={domain}/>:<Redirect to="/" />  }
</Route>
 <Route exact path="/:cname/Story" >
  {a ? <P404 d={domain}/>:<Redirect to="/P404" />  }
  </Route>
  <Route exact path="/:cname/Photo" >
  {a ? <P404 d={domain}/>:<Redirect to="/P404" />  }
  </Route>
  <Route exact path="/:cname/Video" >
  {a ? <P404 d={domain}/>:<Redirect to="/P404" />  }
  </Route>
  <Route exact path="/Live" >
  {a ? <P404 d={domain}/>:<Redirect to="/P404" />  }
  </Route>
  <Route exact path="/Breaking" >
  {a ? <P404 d={domain}/>:<Redirect to="/P404" />  }
  </Route>
  <Route exact path="/Updates" >
  {a ? <P404 d={domain}/>:<Redirect to="/P404" />  }
  </Route>

<Route exact path="/Policy">
  {a ? <Policy d={domain}/>:<Redirect to="/" />  }
</Route>
<Route exact path="/Contact">
  {a ? <Contact d={domain}/>:<Redirect to="/" />  }
</Route>
<Route exact path="/Login">
  {a ? <Login d={domain}/>:<Redirect to="/" />  }
</Route>
<Route exact path="/Search">
  {a ? <Search/>:<Redirect to="/" />  }
</Route>
<Route exact path="/SignUp">
  {a ? <SignUP d={domain}/>:<Redirect to="/" />  }
</Route>
<Route exact path="/SignUp">
  {a ? <SignUP d={domain}/>:<Redirect to="/" />  }
</Route>
<Route exact path="/Shows">
  {a ? <Shows d={domain}/>:<Redirect to="/" />  }
</Route>
<Route exact path="/Shows/:Epi" component={Category}>
  {a ? <Episode />:<Redirect to="/" />  }
</Route>


          <Route  exact path="/:catName"  component={Category}>
          </Route>
          <Route  exact path={`/:catName/:SubCat`} component={Category}>
          </Route>   
          <Route path={`/:cname/:subname/:name`} component={News}>
          </Route>
      
          <Route path="/" component={Home}>
          </Route>
  
        </Switch>
      </Router>
    <style>
      {
        `.MuiTypography-body1 {
          font-size: 15px;
          font-family: 'Roboto', sans-serif;
        }
        .MuiTypography-h6 {
          font-size: 14px;
          font-family: 'Roboto', sans-serif;
        }
.text-secondary {
  color:#292727!important;
        }`
      }
    </style>
     
    </div>
  );
}

export default App;
